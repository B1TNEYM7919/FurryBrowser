import sys
import json
import copy
import math
import os
import shutil
import signal
import subprocess
import time
import traceback
from datetime import datetime
from pathlib import Path
from urllib.parse import quote, urlparse

from PyQt6.QtCore import (
    Qt, QTimer, QSize, QStringListModel, QUrl, QObject, QStandardPaths, pyqtSignal,
    QPointF, QRectF,
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLineEdit, QTabWidget, QTabBar, QToolButton,
    QVBoxLayout, QHBoxLayout, QWidget, QMenu, QDialog, QListWidget,
    QListWidgetItem, QPushButton, QLabel, QCompleter, QCheckBox, QComboBox,
    QGroupBox, QDialogButtonBox, QMessageBox, QProgressBar,
    QGraphicsDropShadowEffect, QSizePolicy, QFrame, QScrollArea,
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import (
    QWebEnginePage, QWebEngineProfile, QWebEngineScript, QWebEngineDownloadRequest,
    QWebEngineSettings,
)
from PyQt6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
from PyQt6.QtGui import (
    QKeySequence, QIcon, QPixmap, QColor, QPalette, QGuiApplication, QDesktopServices,
    QPainter, QPainterPath, QPen, QPolygonF, QAction,
)

_HISTORY = []
_BOOKMARKS = []
_WINDOWS = []
_ZOOM_LEVELS = {}
_PERSISTENT_PROFILE = None
_GEO = None
_NOTIFY = None
_DOWNLOADS = None

SETTINGS_DIR = Path.home() / ".furrybrowser"
SETTINGS_FILE = SETTINGS_DIR / "settings.json"
SESSION_FILE = SETTINGS_DIR / "session.json"
HISTORY_FILE = SETTINGS_DIR / "history.json"
BOOKMARKS_FILE = SETTINGS_DIR / "bookmarks.json"
WINDOW_STATE_FILE = SETTINGS_DIR / "window_state.json"
ZOOM_FILE = SETTINGS_DIR / "zoom_levels.json"
DOWNLOADS_FILE = SETTINGS_DIR / "downloads.json"
PROFILE_DIR = SETTINGS_DIR / "profile"
CACHE_DIR = SETTINGS_DIR / "cache"

if getattr(sys, "frozen", False):
    ASSETS_DIR = Path(sys._MEIPASS) / "assets"
else:
    ASSETS_DIR = Path(__file__).parent / "assets"

DEFAULT_HOME_URL = "https://nex-search-io.vercel.app/"

DEFAULT_SETTINGS = {
    "open_previous_tabs": True,
    "bookmarks_bar": True,
    "default_search_engine": "nex",
    "home_page": DEFAULT_HOME_URL,
    "search_engines": [
        {"id": "nex", "name": "Nex Search", "url": "https://nex-search-io.vercel.app/?q={query}"},
        {"id": "google", "name": "Google", "url": "https://www.google.com/search?q={query}"},
        {"id": "ddg", "name": "DuckDuckGo", "url": "https://duckduckgo.com/?q={query}"},
        {"id": "bing", "name": "Bing", "url": "https://www.bing.com/search?q={query}"},
        {"id": "yandex", "name": "Яндекс", "url": "https://yandex.ru/search/?text={query}"},
    ],
    "address_bar": {
        "history": True,
        "open_tabs": True,
        "bookmarks": True,
    },
    "geolocation": {
        "ip_fallback": True,
    },
    "notifications": {
        "enabled": True,
    },
}


def _set_ask_every_time(profile):
    policy_cls = getattr(QWebEngineProfile, "PersistentPermissionsPolicy", None)
    if policy_cls is None:
        return
    policy = getattr(policy_cls, "AskEveryTime", None)
    if policy is None:
        policy = getattr(policy_cls, "Ask", None)
    if policy is None:
        return
    try:
        profile.setPersistentPermissionsPolicy(policy)
    except (AttributeError, TypeError, RuntimeError):
        pass


def _get_persistent_profile():
    global _PERSISTENT_PROFILE
    if _PERSISTENT_PROFILE is not None:
        return _PERSISTENT_PROFILE

    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    profile = QWebEngineProfile("FurryBrowser", QApplication.instance())
    profile.setPersistentStoragePath(str(PROFILE_DIR))
    profile.setCachePath(str(CACHE_DIR))
    profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
    profile.setPersistentCookiesPolicy(
        QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies
    )
    _set_ask_every_time(profile)

    _PERSISTENT_PROFILE = profile
    if _GEO is not None:
        _GEO.register_profile(profile)
    if _NOTIFY is not None:
        _NOTIFY.register_profile(profile)
    if _DOWNLOADS is not None:
        _DOWNLOADS.register_profile(profile)
    return profile


def is_dark_theme():
    try:
        return QApplication.styleHints().colorScheme() == Qt.ColorScheme.Dark
    except AttributeError:
        window_color = QApplication.palette().color(QPalette.ColorRole.Window)
        return window_color.lightness() < 128


def get_theme_colors():
    if is_dark_theme():
        return {
            "bg": "#1E1E1E",
            "bg_alt": "#252525",
            "bg_input": "#2D2D2D",
            "text": "#E0E0E0",
            "text_muted": "#888888",
            "border": "#3E3E3E",
            "accent": "#4A90E2",
            "hover": "#3E3E3E",
            "pressed": "#505050",
            "tab_bg": "#2D2D2D",
            "tab_selected_bg": "#1E1E1E",
            "shadow": QColor(0, 0, 0, 120),
        }
    return {
        "bg": "#FFFFFF",
        "bg_alt": "#F8F9FA",
        "bg_input": "#F5F5F5",
        "text": "#333333",
        "text_muted": "#888888",
        "border": "#E0E0E0",
        "accent": "#4A90E2",
        "hover": "#E0E0E0",
        "pressed": "#D0D0D0",
        "tab_bg": "#F5F5F5",
        "tab_selected_bg": "#FFFFFF",
        "shadow": QColor(0, 0, 0, 60),
    }


def get_global_style(colors):
    return f"""
        QMainWindow, QDialog {{
            background-color: {colors['bg']};
        }}
        QWidget {{
            font-family: 'Segoe UI', Arial, sans-serif;
            color: {colors['text']};
        }}
        QLabel {{
            color: {colors['text']};
        }}
        QCheckBox {{
            color: {colors['text']};
        }}
        QLineEdit {{
            border: 1px solid {colors['border']};
            border-radius: 16px;
            padding: 6px 12px;
            background-color: {colors['bg_input']};
            color: {colors['text']};
            font-size: 14px;
            selection-background-color: {colors['accent']};
            outline: none;
        }}
        QLineEdit:focus {{
            border: 1px solid {colors['text_muted']};
            background-color: {colors['bg']};
            outline: none;
        }}
        QPushButton {{
            background-color: {colors['accent']};
            color: white;
            border: none;
            border-radius: 8px;
            padding: 8px 16px;
            font-weight: bold;
        }}
        QPushButton:hover {{
            background-color: #357ABD;
        }}
        QPushButton:pressed {{
            background-color: #2E6DA4;
        }}
        QToolButton {{
            border: none;
            border-radius: 6px;
            padding: 6px;
            background-color: transparent;
            color: {colors['text']};
        }}
        QToolButton:hover {{
            background-color: {colors['hover']};
        }}
        QToolButton:pressed {{
            background-color: {colors['pressed']};
        }}
        QTabBar::tab {{
            background: {colors['tab_bg']};
            border: none;
            padding: 6px 8px 6px 12px;
            margin-right: 4px;
            border-radius: 8px;
            color: {colors['text_muted']};
        }}
        QTabBar::tab:hover {{
            background: {colors['hover']};
        }}
        QTabBar::tab:selected {{
            background: {colors['tab_selected_bg']};
            color: {colors['accent']};
            font-weight: bold;
            border: none;
        }}
        QMenu {{
            background-color: {colors['bg']};
            border: 1px solid {colors['border']};
            border-radius: 8px;
            padding: 6px;
            color: {colors['text']};
        }}
        QMenu::item {{
            padding: 8px 24px;
            border-radius: 4px;
            color: {colors['text']};
            background-color: transparent;
        }}
        QMenu::item:selected {{
            background-color: {colors['hover']};
            color: {colors['accent']};
        }}
        QMenu::item:disabled {{
            color: {colors['text_muted']};
        }}
        QMenu::separator {{
            height: 1px;
            background-color: {colors['border']};
            margin: 4px 8px;
        }}
        QMenu::indicator {{
            width: 14px;
            height: 14px;
        }}
        QGroupBox {{
            border: 1px solid {colors['border']};
            border-radius: 8px;
            margin-top: 14px;
            padding-top: 10px;
            color: {colors['text']};
        }}
        QGroupBox::title {{
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
            color: {colors['accent']};
            font-weight: bold;
        }}
        QListWidget {{
            border: 1px solid {colors['border']};
            border-radius: 8px;
            padding: 4px;
            background-color: {colors['bg_input']};
            color: {colors['text']};
            outline: none;
        }}
        QListWidget::item {{
            color: {colors['text']};
            padding: 6px;
        }}
        QListWidget::item:selected {{
            background-color: {colors['hover']};
            color: {colors['accent']};
        }}
        QScrollBar:vertical {{
            border: none;
            background: {colors['bg_alt']};
            width: 8px;
            border-radius: 4px;
        }}
        QScrollBar::handle:vertical {{
            background: {colors['text_muted']};
            border-radius: 4px;
            min-height: 20px;
        }}
        QScrollBar::handle:vertical:hover {{
            background: {colors['text']};
        }}
    """


def load_settings():
    if not SETTINGS_FILE.exists():
        return copy.deepcopy(DEFAULT_SETTINGS)
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        merged = copy.deepcopy(DEFAULT_SETTINGS)
        for k, v in data.items():
            if k in merged and isinstance(merged[k], dict) and isinstance(v, dict):
                merged[k].update(v)
            else:
                merged[k] = v
        return merged
    except Exception:
        return copy.deepcopy(DEFAULT_SETTINGS)


def save_settings(data):
    try:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception as e:
        print(f"Не удалось сохранить настройки: {e}")
        return False


def notifications_enabled():
    try:
        n = load_settings().get("notifications") or {}
        return bool(n.get("enabled", True))
    except Exception:
        return True


def get_search_url(query):
    settings = load_settings()
    engines = settings.get("search_engines", [])
    default_id = settings.get("default_search_engine", "nex")
    encoded = quote(query, safe="")
    for e in engines:
        if e.get("id") == default_id:
            try:
                return QUrl(e["url"].replace("{query}", encoded))
            except Exception:
                break
    return QUrl("https://nex-search-io.vercel.app/?q=" + encoded)


def get_home_url():
    settings = load_settings()
    url = (settings.get("home_page") or "").strip()
    if not url or url == DEFAULT_HOME_URL:
        home_file = ASSETS_DIR / "home.html"
        if home_file.exists():
            return QUrl.fromLocalFile(str(home_file))
        return QUrl(DEFAULT_HOME_URL)
    qurl = QUrl(url)
    if not qurl.scheme():
        qurl = QUrl("https://" + url)
    return qurl


def _load_history():
    if not HISTORY_FILE.exists():
        return []
    try:
        data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        out = []
        for item in data:
            if isinstance(item, (list, tuple)) and len(item) >= 3:
                out.append((item[0], item[1], item[2]))
        return out
    except Exception:
        return []


def _save_history():
    try:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        HISTORY_FILE.write_text(json.dumps(_HISTORY[-2000:], ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"Не удалось сохранить историю: {e}")


def _bookmark_key(url):
    u = (url or "").strip()
    if not u:
        return ""
    try:
        qurl = QUrl(u)
        if qurl.isValid() and qurl.scheme():
            qurl.setFragment("")
            qurl.setScheme(qurl.scheme().lower())
            if qurl.host():
                qurl.setHost(qurl.host().lower())
            text = qurl.toString()
            if text:
                return text.rstrip("/")
    except Exception:
        pass
    if "#" in u:
        u = u.split("#", 1)[0]
    return u.rstrip("/")


def _find_bookmark(url):
    key = _bookmark_key(url)
    if not key:
        return None
    for bookmark in _BOOKMARKS:
        if _bookmark_key(bookmark.get("url")) == key:
            return bookmark
    return None


def _load_bookmarks():
    if not BOOKMARKS_FILE.exists():
        return []
    try:
        data = json.loads(BOOKMARKS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        bookmarks = []
        for item in data:
            if not isinstance(item, dict):
                continue
            url = str(item.get("url") or "").strip()
            if not url:
                continue
            bookmarks.append({
                "url": url,
                "title": str(item.get("title") or url),
                "added": str(item.get("added") or ""),
            })
        return bookmarks
    except Exception as e:
        print(f"Не удалось загрузить закладки: {e}")
        return []


def _save_bookmarks():
    try:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        BOOKMARKS_FILE.write_text(
            json.dumps(_BOOKMARKS, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception as e:
        print(f"Не удалось сохранить закладки: {e}")


def add_bookmark(url, title=""):
    url = (url or "").strip()
    if not url or url == "about:blank" or url.startswith("furrybrowser:"):
        return None
    existing = _find_bookmark(url)
    if existing is not None:
        return existing
    bookmark = {
        "url": url,
        "title": (title or "").strip() or url,
        "added": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    _BOOKMARKS.append(bookmark)
    _save_bookmarks()
    return bookmark


def remove_bookmark(url):
    bookmark = _find_bookmark(url)
    if bookmark is None:
        return False
    _BOOKMARKS.remove(bookmark)
    _save_bookmarks()
    return True


def _refresh_bookmark_ui():
    for window in list(_WINDOWS):
        try:
            window.refresh_bookmarks()
        except (RuntimeError, AttributeError):
            continue


def _load_zoom_levels():
    global _ZOOM_LEVELS
    _ZOOM_LEVELS = {}
    if not ZOOM_FILE.exists():
        return
    try:
        data = json.loads(ZOOM_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, (int, float)):
                    _ZOOM_LEVELS[str(k)] = float(v)
    except Exception:
        _ZOOM_LEVELS = {}


def _save_zoom_levels():
    try:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        ZOOM_FILE.write_text(json.dumps(_ZOOM_LEVELS), encoding="utf-8")
    except Exception as e:
        print(f"Не удалось сохранить уровни масштаба: {e}")


def _capture_window(w):
    tabs = []
    active = 0
    try:
        current = w.tabs.currentWidget()
        for i in range(w.tabs.count()):
            b = w.tabs.widget(i)
            if b is None:
                continue
            if id(b) in w.discarded_urls:
                u = w.discarded_urls[id(b)].toString()
            else:
                try:
                    u = b.url().toString()
                except Exception:
                    continue
            if not u or u in ("about:blank", ""):
                continue
            if u.startswith("furrybrowser:"):
                continue
            if b is current:
                active = len(tabs)
            tabs.append(u)
    except (RuntimeError, AttributeError):
        pass
    return {"tabs": tabs, "active": active}


def _save_current_sessions():
    windows_data = []
    for w in list(_WINDOWS):
        if getattr(w, "private", False):
            continue
        try:
            if not w.isVisible():
                continue
            d = _capture_window(w)
            if d["tabs"]:
                windows_data.append(d)
        except (RuntimeError, AttributeError):
            continue
    try:
        SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
        if windows_data:
            SESSION_FILE.write_text(
                json.dumps({"windows": windows_data}, ensure_ascii=False),
                encoding="utf-8",
            )
    except Exception as e:
        print(f"Не удалось сохранить сессию: {e}")


_GEO_POLYFILL_JS = r"""
(function () {
  if (window.__furryGeoPatched) return;
  if (typeof Geolocation === 'undefined' || !navigator.geolocation) return;
  window.__furryGeoPatched = true;

  var P = Geolocation.prototype;
  var origGet = P.getCurrentPosition;
  var origWatch = P.watchPosition;
  var origClear = P.clearWatch;
  var watches = {};
  var nextId = 900000000;

  function makePos() {
    var g = window.__furryGeo;
    if (!g) return null;
    return {
      coords: {
        latitude: g.lat, longitude: g.lon, accuracy: g.acc,
        altitude: null, altitudeAccuracy: null, heading: null, speed: null
      },
      timestamp: Date.now()
    };
  }

  function waitGeo(cb) {
    if (window.__furryGeoOn === false) { cb(null); return; }
    var t0 = Date.now();
    (function poll() {
      var p = makePos();
      if (p) { cb(p); return; }
      if (Date.now() - t0 > 8000 || window.__furryGeoOn === false) { cb(null); return; }
      setTimeout(poll, 200);
    })();
  }

  function fallbackable(e) { return e && (e.code === 2 || e.code === 3); }

  P.getCurrentPosition = function (ok, err, opts) {
    var self = this;
    origGet.call(self, ok, function (e) {
      if (!fallbackable(e)) { if (err) err(e); return; }
      waitGeo(function (p) {
        if (p) { try { ok(p); } catch (x) { console.error(x); } }
        else if (err) { err(e); }
      });
    }, opts);
  };

  P.watchPosition = function (ok, err, opts) {
    var self = this;
    var id = nextId++;
    var w = { real: null, timer: null, fb: false, dead: false };
    watches[id] = w;
    w.real = origWatch.call(self, ok, function (e) {
      if (w.dead) return;
      if (!fallbackable(e) || w.fb) { if (err) err(e); return; }
      waitGeo(function (p) {
        if (w.dead) return;
        if (!p) { if (err) err(e); return; }
        w.fb = true;
        try { origClear.call(self, w.real); } catch (x) {}
        try { ok(p); } catch (x) { console.error(x); }
        w.timer = setInterval(function () {
          var q = makePos();
          if (q) { try { ok(q); } catch (x) { console.error(x); } }
        }, 30000);
      });
    }, opts);
    return id;
  };

  P.clearWatch = function (id) {
    var w = watches[id];
    if (!w) return origClear.call(this, id);
    w.dead = true;
    if (w.timer) clearInterval(w.timer);
    if (!w.fb) { try { origClear.call(this, w.real); } catch (x) {} }
    delete watches[id];
  };
})();
"""


class GeoLocator(QObject):
    SCRIPT_NAME = "furry-geo"
    TTL = 30 * 60
    PROVIDERS = [
        ("https://ipwho.is/", "ipwho"),
        ("https://ipapi.co/json/", "ipapi"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.nam = QNetworkAccessManager(self)
        self.location = None
        self._ts = 0.0
        self._busy = False
        self._profiles = []

    def enabled(self):
        try:
            geo = load_settings().get("geolocation") or {}
            return bool(geo.get("ip_fallback", True))
        except Exception:
            return True

    def reconfigure(self):
        if not self.enabled():
            self.location = None
            self._ts = 0.0
        self._publish()

    def register_profile(self, profile):
        if profile not in self._profiles:
            self._profiles.append(profile)
        self._install(profile)

    def unregister_profile(self, profile):
        try:
            self._profiles.remove(profile)
        except ValueError:
            pass

    def _state_js(self):
        on = self.enabled()
        loc = self.location if on else None
        if loc:
            geo = json.dumps({"lat": loc["lat"], "lon": loc["lon"], "acc": loc["acc"]})
        else:
            geo = "null"
        return (
            f"window.__furryGeoOn={'true' if on else 'false'};"
            f"window.__furryGeo={geo};"
        )

    def _make_script(self):
        s = QWebEngineScript()
        s.setName(self.SCRIPT_NAME)
        s.setSourceCode(self._state_js() + "\n" + _GEO_POLYFILL_JS)
        s.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        s.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        s.setRunsOnSubFrames(True)
        return s

    def _install(self, profile):
        try:
            coll = profile.scripts()
            for old in coll.find(self.SCRIPT_NAME):
                coll.remove(old)
            coll.insert(self._make_script())
        except RuntimeError:
            self.unregister_profile(profile)
        except Exception as e:
            print(f"Не удалось установить скрипт геолокации: {e}")

    def _publish(self):
        for p in list(self._profiles):
            self._install(p)
        js = self._state_js()
        for w in list(_WINDOWS):
            try:
                for i in range(w.tabs.count()):
                    b = w.tabs.widget(i)
                    if b is not None and b.page():
                        b.page().runJavaScript(js)
            except (RuntimeError, AttributeError):
                continue

    def ensure(self):
        if not self.enabled() or self._busy:
            return
        if self.location and (time.time() - self._ts) < self.TTL:
            return
        self._busy = True
        self._try(0)

    def _try(self, i):
        if i >= len(self.PROVIDERS):
            self._busy = False
            return
        url, kind = self.PROVIDERS[i]
        req = QNetworkRequest(QUrl(url))
        req.setTransferTimeout(8000)
        req.setAttribute(
            QNetworkRequest.Attribute.RedirectPolicyAttribute,
            QNetworkRequest.RedirectPolicy.NoLessSafeRedirectPolicy,
        )
        reply = self.nam.get(req)
        reply.finished.connect(lambda r=reply, idx=i, k=kind: self._on_reply(r, idx, k))

    def _on_reply(self, reply, index, kind):
        try:
            if reply.error() != QNetworkReply.NetworkError.NoError:
                raise RuntimeError(reply.errorString())
            data = json.loads(bytes(reply.readAll()).decode("utf-8", "replace"))
            if kind == "ipwho" and not data.get("success", False):
                raise RuntimeError("provider reported failure")
            lat = float(data["latitude"])
            lon = float(data["longitude"])
            if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
                raise ValueError("bad coordinates")
        except Exception as e:
            print(f"Геолокация по IP ({kind}) не удалась: {e}")
            reply.deleteLater()
            self._try(index + 1)
            return

        reply.deleteLater()
        self.location = {"lat": lat, "lon": lon, "acc": 5000.0}
        self._ts = time.time()
        self._busy = False
        self._publish()


class NotificationToast(QWidget):
    CARD_WIDTH = 340
    TIMEOUT_MS = 8000
    HOVER_LEAVE_MS = 2500

    def __init__(self, notification, manager):
        super().__init__(None)
        self.colors = get_theme_colors()
        self.notification = notification
        self.manager = manager
        self._finished = False

        try:
            self.tag = notification.tag() or ""
        except Exception:
            self.tag = ""
        try:
            self.origin_url = notification.origin()
        except Exception:
            self.origin_url = QUrl()

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)

        card = QFrame()
        card.setObjectName("ToastCard")
        card.setFixedWidth(self.CARD_WIDTH)
        card.setStyleSheet(
            f"QFrame#ToastCard {{ background-color: {self.colors['bg']};"
            f" border: 1px solid {self.colors['border']}; border-radius: 12px; }}"
            f"QFrame#ToastCard QLabel {{ background: transparent; border: none; }}"
        )
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(18)
        shadow.setColor(self.colors["shadow"])
        shadow.setOffset(0, 3)
        card.setGraphicsEffect(shadow)
        outer.addWidget(card)

        row = QHBoxLayout(card)
        row.setContentsMargins(12, 10, 8, 12)
        row.setSpacing(10)

        icon_label = QLabel()
        icon_label.setFixedSize(40, 40)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pm = None
        try:
            img = notification.icon()
            if img is not None and not img.isNull():
                pm = QPixmap.fromImage(img).scaled(
                    40, 40,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
        except Exception:
            pm = None
        if pm is None:
            pm = _app_icon().pixmap(QSize(40, 40))
        icon_label.setPixmap(pm)
        row.addWidget(icon_label, 0, Qt.AlignmentFlag.AlignTop)

        col = QVBoxLayout()
        col.setSpacing(2)

        host = ""
        try:
            host = self.origin_url.host() or self.origin_url.toString()
        except Exception:
            pass
        origin_label = QLabel(host)
        origin_label.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 11px;")
        col.addWidget(origin_label)

        title_text = self._clip(self._safe(notification.title), 120) or host
        title_label = QLabel(title_text)
        title_label.setWordWrap(True)
        title_label.setTextFormat(Qt.TextFormat.PlainText)
        title_label.setStyleSheet(
            f"color: {self.colors['text']}; font-size: 14px; font-weight: bold;"
        )
        col.addWidget(title_label)

        msg_text = self._clip(self._safe(notification.message), 240)
        if msg_text:
            msg_label = QLabel(msg_text)
            msg_label.setWordWrap(True)
            msg_label.setTextFormat(Qt.TextFormat.PlainText)
            msg_label.setStyleSheet(f"color: {self.colors['text']}; font-size: 13px;")
            col.addWidget(msg_label)

        row.addLayout(col, 1)

        close_btn = QToolButton()
        close_btn.setIcon(_make_icon("close", self.colors["text_muted"], 14, "#FFFFFF"))
        close_btn.setIconSize(QSize(12, 12))
        close_btn.setFixedSize(22, 22)
        close_btn.setCursor(Qt.CursorShape.ArrowCursor)
        close_btn.setStyleSheet(
            "QToolButton { border: none; border-radius: 11px; padding: 0px; background: transparent; }"
            "QToolButton:hover { background: #FF5C5C; }"
        )
        close_btn.clicked.connect(lambda: self.dismiss(from_page=False))
        row.addWidget(close_btn, 0, Qt.AlignmentFlag.AlignTop)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(lambda: self.dismiss(from_page=False))
        self._timer.start(self.TIMEOUT_MS)

        self.adjustSize()

    @staticmethod
    def _safe(getter):
        try:
            return str(getter() or "")
        except Exception:
            return ""

    @staticmethod
    def _clip(text, limit):
        text = " ".join(text.split())
        return text if len(text) <= limit else text[: limit - 1] + "…"

    def enterEvent(self, event):
        self._timer.stop()
        super().enterEvent(event)

    def leaveEvent(self, event):
        if not self._finished:
            self._timer.start(self.HOVER_LEAVE_MS)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.manager.activate(self)
            return
        super().mousePressEvent(event)

    def dismiss(self, from_page=False):
        if self._finished:
            return
        self._finished = True
        self._timer.stop()
        if not from_page:
            try:
                self.notification.close()
            except Exception:
                pass
        self.manager.remove(self)
        self.hide()
        self.deleteLater()


class NotificationManager(QObject):
    MARGIN = 12
    SPACING = 2
    MAX_VISIBLE = 5

    def __init__(self, parent=None):
        super().__init__(parent)
        self._toasts = []
        self._profiles = []

    def enabled(self):
        return notifications_enabled()

    def register_profile(self, profile):
        try:
            profile.setNotificationPresenter(self.present)
            if profile not in self._profiles:
                self._profiles.append(profile)
        except Exception as e:
            print(f"Не удалось подключить уведомления: {e}")

    def unregister_profile(self, profile):
        try:
            self._profiles.remove(profile)
        except ValueError:
            pass

    def present(self, notification):
        try:
            if not self.enabled():
                try:
                    notification.close()
                except Exception:
                    pass
                return

            try:
                tag = notification.tag() or ""
                origin = notification.origin()
            except Exception:
                tag, origin = "", QUrl()
            if tag:
                for old in list(self._toasts):
                    if old.tag == tag and old.origin_url == origin:
                        old.dismiss(from_page=False)

            toast = NotificationToast(notification, self)
            try:
                notification.closed.connect(
                    lambda t=toast: t.dismiss(from_page=True)
                )
            except Exception:
                pass

            self._toasts.append(toast)
            while len(self._toasts) > self.MAX_VISIBLE:
                self._toasts[0].dismiss(from_page=False)

            try:
                notification.show()
            except Exception:
                pass

            self._layout()
            toast.show()
        except Exception as e:
            print(f"Ошибка показа уведомления: {e}")
            try:
                notification.close()
            except Exception:
                pass

    def remove(self, toast):
        try:
            self._toasts.remove(toast)
        except ValueError:
            pass
        self._layout()

    def close_all(self):
        for t in list(self._toasts):
            t.dismiss(from_page=False)

    def _layout(self):
        screen = QApplication.primaryScreen()
        if screen is None:
            return
        geo = screen.availableGeometry()
        y = geo.bottom() + 1 - self.MARGIN
        for t in reversed(self._toasts):
            t.adjustSize()
            y -= t.height()
            x = geo.right() + 1 - t.width() - self.MARGIN + 10
            t.move(x, y)
            y -= self.SPACING

    def activate(self, toast):
        notification = toast.notification
        try:
            notification.click()
        except Exception:
            pass
        self._focus_origin_tab(toast.origin_url)
        toast.dismiss(from_page=False)

    def _focus_origin_tab(self, origin):
        try:
            host = origin.host()
        except Exception:
            host = ""
        target = None
        for w in list(_WINDOWS):
            try:
                for i in range(w.tabs.count()):
                    b = w.tabs.widget(i)
                    if b is not None and host and b.url().host() == host:
                        w.tabs.setCurrentIndex(i)
                        target = w
                        break
            except (RuntimeError, AttributeError):
                continue
            if target is not None:
                break
        if target is None and _WINDOWS:
            target = _WINDOWS[-1]
        if target is not None:
            try:
                target.setWindowState(
                    target.windowState() & ~Qt.WindowState.WindowMinimized
                )
                target.show()
                target.raise_()
                target.activateWindow()
            except RuntimeError:
                pass


ACTIVE_STATES = ("progress", "paused")


def fmt_size(n):
    n = float(max(n or 0, 0))
    for unit in ("Б", "КБ", "МБ", "ГБ", "ТБ"):
        if n < 1024 or unit == "ТБ":
            if unit == "Б":
                return f"{int(n)} Б"
            return f"{n:.1f}".replace(".", ",") + f" {unit}"
        n /= 1024.0


def fmt_speed(bps):
    return fmt_size(bps) + "/с"


def fmt_eta(sec):
    sec = int(sec)
    if sec < 5:
        return "несколько секунд"
    if sec < 60:
        return f"{sec} с"
    if sec < 3600:
        return f"{sec // 60} мин"
    h, m = divmod(sec // 60, 60)
    return f"{h} ч {m} мин" if m else f"{h} ч"


def fmt_when(ts):
    d = datetime.fromtimestamp(ts)
    if d.date() == datetime.now().date():
        return d.strftime("%H:%M")
    return d.strftime("%d.%m.%Y %H:%M")


def open_file(path):
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


def reveal_in_folder(path):
    path = str(path)
    try:
        if sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            return
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
            return
    except Exception:
        pass
    folder = os.path.dirname(path) or "."
    QDesktopServices.openUrl(QUrl.fromLocalFile(folder))


def _icon_pixmap(kind, color, size=20):
    scale = 2
    px = QPixmap(size * scale, size * scale)
    px.fill(Qt.GlobalColor.transparent)
    px.setDevicePixelRatio(scale)
    p = QPainter(px)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c = QColor(color)
    s = float(size)
    pen = QPen(c, max(1.4, s * 0.08))
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)

    def pt(x, y):
        return QPointF(s * x, s * y)

    def outline(points, close=True):
        path = QPainterPath()
        path.moveTo(pt(*points[0]))
        for x, y in points[1:]:
            path.lineTo(pt(x, y))
        if close:
            path.closeSubpath()
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)

    def solid():
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)

    def stroke():
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)

    if kind == "pause":
        solid()
        p.drawRoundedRect(QRectF(s * .27, s * .2, s * .16, s * .6), 1.5, 1.5)
        p.drawRoundedRect(QRectF(s * .57, s * .2, s * .16, s * .6), 1.5, 1.5)
    elif kind == "play":
        solid()
        p.drawPolygon(QPolygonF([pt(.3, .18), pt(.8, .5), pt(.3, .82)]))
    elif kind == "stop":
        solid()
        p.drawRoundedRect(QRectF(s * .24, s * .24, s * .52, s * .52), 2, 2)
    elif kind == "file":
        outline([(.25, .12), (.58, .12), (.78, .32), (.78, .88), (.25, .88)])
        outline([(.58, .12), (.58, .32), (.78, .32)], close=False)
    elif kind == "folder":
        outline([(.1, .26), (.38, .26), (.46, .37), (.9, .37), (.9, .8), (.1, .8)])
    elif kind == "trash":
        outline([(.16, .28), (.84, .28)], close=False)
        outline([(.4, .28), (.4, .15), (.6, .15), (.6, .28)], close=False)
        outline([(.26, .28), (.3, .86), (.7, .86), (.74, .28)], close=False)
        outline([(.43, .44), (.43, .7)], close=False)
        outline([(.57, .44), (.57, .7)], close=False)
    elif kind == "menu":
        for y in (.3, .5, .7):
            outline([(.2, y), (.8, y)], close=False)
    elif kind == "back":
        outline([(.8, .5), (.22, .5)], close=False)
        outline([(.48, .24), (.22, .5), (.48, .76)], close=False)
    elif kind == "forward":
        outline([(.2, .5), (.78, .5)], close=False)
        outline([(.52, .24), (.78, .5), (.52, .76)], close=False)
    elif kind == "reload":
        rect = QRectF(s * .2, s * .2, s * .6, s * .6)
        path = QPainterPath()
        path.arcMoveTo(rect, 60)
        path.arcTo(rect, 60, 300)
        stroke()
        p.drawPath(path)
        solid()
        p.drawPolygon(QPolygonF([pt(.8, .3), pt(.96, .56), pt(.64, .56)]))
    elif kind == "home":
        outline([(.14, .5), (.5, .17), (.86, .5)], close=False)
        outline([(.25, .44), (.25, .84), (.75, .84), (.75, .44)], close=False)
        outline([(.43, .84), (.43, .6), (.57, .6), (.57, .84)], close=False)
    elif kind == "minimize":
        outline([(.24, .62), (.76, .62)], close=False)
    elif kind == "maximize":
        outline([(.24, .24), (.76, .24), (.76, .76), (.24, .76)])
    elif kind == "restore":
        outline([(.2, .34), (.66, .34), (.66, .8), (.2, .8)])
        outline([(.34, .34), (.34, .2), (.8, .2), (.8, .66), (.66, .66)], close=False)
    elif kind == "close":
        outline([(.25, .25), (.75, .75)], close=False)
        outline([(.75, .25), (.25, .75)], close=False)
    elif kind == "up":
        outline([(.5, .8), (.5, .22)], close=False)
        outline([(.25, .46), (.5, .22), (.75, .46)], close=False)
    elif kind == "down":
        outline([(.5, .2), (.5, .78)], close=False)
        outline([(.25, .54), (.5, .78), (.75, .54)], close=False)
    elif kind == "plus":
        outline([(.5, .22), (.5, .78)], close=False)
        outline([(.22, .5), (.78, .5)], close=False)
    elif kind == "pin":
        outline([(.38, .14), (.62, .14), (.58, .44), (.74, .58),
                 (.26, .58), (.42, .44)])
        outline([(.5, .58), (.5, .88)], close=False)
    elif kind == "sleep":
        a = QPainterPath()
        a.addEllipse(QRectF(s * .2, s * .2, s * .6, s * .6))
        b = QPainterPath()
        b.addEllipse(QRectF(s * .4, s * .1, s * .55, s * .55))
        solid()
        p.drawPath(a.subtracted(b))
    elif kind == "globe":
        stroke()
        p.drawEllipse(QRectF(s * .18, s * .18, s * .64, s * .64))
        p.drawEllipse(QRectF(s * .36, s * .18, s * .28, s * .64))
        p.drawLine(pt(.18, .5), pt(.82, .5))
    elif kind == "lock":
        outline([(.25, .45), (.75, .45), (.75, .84), (.25, .84)])
        path = QPainterPath()
        path.moveTo(pt(.35, .45))
        path.lineTo(pt(.35, .35))
        path.arcTo(QRectF(s * .35, s * .15, s * .3, s * .4), 180, -180)
        path.lineTo(pt(.65, .45))
        stroke()
        p.drawPath(path)
    elif kind == "paw":
        solid()
        p.drawEllipse(QRectF(s * .28, s * .5, s * .44, s * .34))
        p.drawEllipse(QRectF(s * .10, s * .38, s * .17, s * .22))
        p.drawEllipse(QRectF(s * .31, s * .16, s * .17, s * .24))
        p.drawEllipse(QRectF(s * .52, s * .16, s * .17, s * .24))
        p.drawEllipse(QRectF(s * .73, s * .38, s * .17, s * .22))
    elif kind in ("star", "star_filled"):
        star = []
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = s * (0.36 if i % 2 == 0 else 0.155)
            star.append(QPointF(
                s * 0.5 + radius * math.cos(angle),
                s * 0.5 + radius * math.sin(angle),
            ))
        path = QPainterPath()
        path.addPolygon(QPolygonF(star))
        path.closeSubpath()
        if kind == "star_filled":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(c)
        else:
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
    p.end()
    return px


def _make_icon(kind, color, size=20, hover_color=None):
    icon = QIcon()
    icon.addPixmap(_icon_pixmap(kind, color, size), QIcon.Mode.Normal)
    if hover_color:
        icon.addPixmap(_icon_pixmap(kind, hover_color, size), QIcon.Mode.Active)
    return icon


def _app_icon():
    path = ASSETS_DIR / "icon.png"
    if path.exists():
        ic = QIcon(str(path))
        if not ic.isNull():
            return ic
    ic = QIcon()
    for sz in (16, 24, 32, 48, 64, 128):
        ic.addPixmap(_icon_pixmap("paw", "#4A90E2", sz))
    return ic


class DownloadItem(QObject):
    changed = pyqtSignal()

    def __init__(self, request=None, data=None, private=False, parent=None):
        super().__init__(parent)
        self.request = request
        self.private = private
        self.error = ""
        self.speed = 0.0
        self._last_t = time.time()
        self._last_recv = 0
        self.finished = 0.0

        if request is not None:
            self.name = request.downloadFileName()
            self.directory = request.downloadDirectory()
            self.url = request.url().toString()
            self.total = request.totalBytes()
            self.received = request.receivedBytes()
            self.state = "progress"
            self.started = time.time()
            request.receivedBytesChanged.connect(self._on_progress)
            request.totalBytesChanged.connect(self._on_progress)
            request.stateChanged.connect(self._on_state)
            request.isPausedChanged.connect(self._on_paused)
        else:
            data = data or {}
            self.name = data.get("name", "")
            self.directory = data.get("directory", "")
            self.url = data.get("url", "")
            self.total = int(data.get("total", 0))
            self.received = int(data.get("received", 0))
            self.state = data.get("state", "done")
            self.started = float(data.get("started", time.time()))
            self.finished = float(data.get("finished", 0))
            self.error = data.get("error", "")

    @property
    def path(self):
        return os.path.join(self.directory, self.name)

    @property
    def active(self):
        return self.state in ACTIVE_STATES

    def to_dict(self):
        return {
            "name": self.name, "directory": self.directory, "url": self.url,
            "total": self.total, "received": self.received, "state": self.state,
            "started": self.started, "finished": self.finished, "error": self.error,
        }

    def _on_progress(self, *_):
        try:
            self.received = self.request.receivedBytes()
            self.total = self.request.totalBytes()
        except (RuntimeError, AttributeError):
            pass

    def _on_paused(self, *_):
        try:
            paused = self.request.isPaused()
        except (RuntimeError, AttributeError):
            return
        if self.state in ACTIVE_STATES:
            self.state = "paused" if paused else "progress"
            self.speed = 0.0
            self._last_t = time.time()
            self._last_recv = self.received
            self.changed.emit()

    def _on_state(self, state):
        S = QWebEngineDownloadRequest.DownloadState
        try:
            self.received = self.request.receivedBytes()
            self.total = self.request.totalBytes()
        except (RuntimeError, AttributeError):
            pass
        if state == S.DownloadCompleted:
            try:
                self.directory = self.request.downloadDirectory()
                self.name = self.request.downloadFileName()
            except (RuntimeError, AttributeError):
                pass
            if self.total <= 0:
                self.total = self.received
            self.state = "done"
            self._finish()
        elif state == S.DownloadCancelled:
            self.state = "cancelled"
            self._finish()
        elif state == S.DownloadInterrupted:
            self.state = "failed"
            try:
                self.error = self.request.interruptReasonString()
            except (RuntimeError, AttributeError):
                self.error = ""
            self._finish()
        elif state == S.DownloadInProgress:
            self.state = "progress"
        self.changed.emit()

    def _finish(self):
        self.finished = time.time()
        self.speed = 0.0
        self.request = None

    def pause(self):
        if self.request is not None and self.state == "progress":
            try:
                self.request.pause()
            except RuntimeError:
                pass

    def resume(self):
        if self.request is not None and self.state == "paused":
            try:
                self.request.resume()
            except RuntimeError:
                pass

    def cancel(self):
        if self.request is not None and self.active:
            try:
                self.request.cancel()
            except RuntimeError:
                pass

    def update_speed(self, now):
        if self.state != "progress":
            self.speed = 0.0
            self._last_t = now
            self._last_recv = self.received
            return
        dt = now - self._last_t
        if dt <= 0:
            return
        inst = max(self.received - self._last_recv, 0) / dt
        self.speed = inst if self.speed <= 0 else 0.6 * self.speed + 0.4 * inst
        self._last_t = now
        self._last_recv = self.received


class DownloadManager(QObject):
    item_added = pyqtSignal(object)
    item_removed = pyqtSignal(object)
    updated = pyqtSignal()

    MAX_SAVED = 500

    def __init__(self, data_file, colors_fn, style_fn, parent=None):
        super().__init__(parent)
        self.data_file = Path(data_file)
        self.colors_fn = colors_fn
        self.style_fn = style_fn
        self.items = []
        self._dialog = None

        self._timer = QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._tick)

        self._load()

    def register_profile(self, profile, private=False):
        profile.downloadRequested.connect(
            lambda req, p=private: self._on_requested(req, p)
        )

    def _load(self):
        if not self.data_file.exists():
            return
        try:
            data = json.loads(self.data_file.read_text(encoding="utf-8"))
            for d in data if isinstance(data, list) else []:
                if isinstance(d, dict) and d.get("name"):
                    item = DownloadItem(data=d, parent=self)
                    item.changed.connect(self._on_item_changed)
                    self.items.append(item)
        except Exception as e:
            print(f"Не удалось загрузить список загрузок: {e}")

    def _save(self):
        try:
            self.data_file.parent.mkdir(parents=True, exist_ok=True)
            data = [
                i.to_dict() for i in self.items
                if not i.private and not i.active
            ][: self.MAX_SAVED]
            self.data_file.write_text(
                json.dumps(data, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as e:
            print(f"Не удалось сохранить список загрузок: {e}")

    @staticmethod
    def _download_dir():
        d = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.DownloadLocation
        ) or str(Path.home() / "Downloads")
        Path(d).mkdir(parents=True, exist_ok=True)
        return d

    def _unique_name(self, directory, name):
        name = os.path.basename(name) or "download"
        busy = {i.path for i in self.items if i.active}
        stem, ext = os.path.splitext(name)
        candidate, n = name, 1
        while os.path.exists(os.path.join(directory, candidate)) or \
                os.path.join(directory, candidate) in busy:
            candidate = f"{stem} ({n}){ext}"
            n += 1
        return candidate

    def _on_requested(self, req, private):
        try:
            directory = self._download_dir()
            req.setDownloadDirectory(directory)
            req.setDownloadFileName(
                self._unique_name(directory, req.downloadFileName())
            )
            req.accept()
        except Exception as e:
            print(f"Ошибка запуска загрузки: {e}")
            try:
                req.cancel()
            except Exception:
                pass
            return

        item = DownloadItem(request=req, private=private, parent=self)
        item.changed.connect(self._on_item_changed)
        self.items.insert(0, item)
        self.item_added.emit(item)
        if not self._timer.isActive():
            self._timer.start()
        self.show_dialog()
        self.updated.emit()

    def _on_item_changed(self):
        self._save()
        self.updated.emit()

    def _tick(self):
        now = time.time()
        active = [i for i in self.items if i.active]
        for i in active:
            i.update_speed(now)
            i.changed.emit()
        if not active:
            self._timer.stop()

    def remove(self, item, delete_file=False):
        item.cancel()
        if delete_file:
            try:
                if os.path.exists(item.path):
                    os.remove(item.path)
            except OSError as e:
                print(f"Не удалось удалить файл: {e}")
        if item in self.items:
            self.items.remove(item)
        self.item_removed.emit(item)
        self._save()
        self.updated.emit()

    def clear_finished(self):
        for i in [i for i in self.items if not i.active]:
            self.remove(i)

    def clear_all_history(self):
        self.clear_finished()

    def shutdown(self):
        for i in list(self.items):
            if i.active:
                i.cancel()
                if i.active:
                    i.state = "failed"
                    i.error = "Прервано при закрытии браузера"
        self._timer.stop()
        self._save()

    def show_dialog(self):
        if self._dialog is None:
            self._dialog = DownloadsDialog(self)
        self._dialog.show()
        self._dialog.raise_()
        self._dialog.activateWindow()


class DownloadRow(QFrame):
    def __init__(self, item, manager, colors, parent=None):
        super().__init__(parent)
        self.item = item
        self.manager = manager
        self.colors = colors
        self._full_name = ""

        self.setObjectName("DlRow")
        self.setStyleSheet(
            f"QFrame#DlRow {{ background-color: {colors['bg_alt']};"
            f" border: 1px solid {colors['border']}; border-radius: 10px; }}"
            f"QFrame#DlRow QLabel {{ background: transparent; border: none; }}"
        )

        row = QHBoxLayout(self)
        row.setContentsMargins(12, 10, 10, 10)
        row.setSpacing(10)

        self.icon = QLabel()
        self.icon.setPixmap(_icon_pixmap("file", colors["accent"], 28))
        self.icon.setFixedWidth(34)
        self.icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        row.addWidget(self.icon, 0, Qt.AlignmentFlag.AlignVCenter)

        col = QVBoxLayout()
        col.setSpacing(4)
        self.name_label = QLabel()
        self.name_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        self.name_label.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        self.name_label.setMinimumWidth(0)
        col.addWidget(self.name_label)

        self.bar = QProgressBar()
        self.bar.setFixedHeight(6)
        self.bar.setTextVisible(False)
        self.bar.setStyleSheet(
            f"QProgressBar {{ border: none; border-radius: 3px;"
            f" background-color: {colors['bg_input']}; }}"
            f"QProgressBar::chunk {{ border-radius: 3px;"
            f" background-color: {colors['accent']}; }}"
        )
        col.addWidget(self.bar)

        self.status_label = QLabel()
        self.status_label.setStyleSheet(
            f"color: {colors['text_muted']}; font-size: 12px;"
        )
        self.status_label.setWordWrap(True)
        col.addWidget(self.status_label)
        row.addLayout(col, 1)

        btn_style = (
            f"QToolButton {{ border: none; border-radius: 6px; font-size: 15px;"
            f" padding: 0px; color: {colors['text']}; }}"
            f"QToolButton:hover {{ background-color: {colors['hover']}; }}"
            f"QToolButton:pressed {{ background-color: {colors['pressed']}; }}"
        )

        def make_btn(kind, tip, slot):
            b = QToolButton()
            b.setIcon(_make_icon(kind, colors["text"]))
            b.setIconSize(QSize(18, 18))
            b.setToolTip(tip)
            b.setFixedSize(32, 32)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(btn_style)
            b.clicked.connect(slot)
            row.addWidget(b, 0, Qt.AlignmentFlag.AlignVCenter)
            return b

        self.pause_btn = make_btn("pause", "Приостановить", self._on_pause_resume)
        self.cancel_btn = make_btn("stop", "Отменить загрузку", lambda: self.item.cancel())
        self.open_btn = make_btn("file", "Открыть файл", self._on_open)
        self.folder_btn = make_btn("folder", "Показать в папке", self._on_folder)
        self.delete_btn = make_btn("trash", "Удалить", self._on_delete)
        self._icon_pause = _make_icon("pause", colors["text"])
        self._icon_play = _make_icon("play", colors["text"])

        item.changed.connect(self.refresh)
        self.refresh()

    def _on_pause_resume(self):
        if self.item.state == "paused":
            self.item.resume()
        else:
            self.item.pause()

    def _on_open(self):
        if os.path.exists(self.item.path):
            open_file(self.item.path)
        else:
            self.refresh()

    def _on_folder(self):
        reveal_in_folder(self.item.path)

    def _on_delete(self):
        menu = QMenu(self)
        menu.setStyleSheet(self.manager.style_fn(self.colors))
        file_exists = os.path.exists(self.item.path) and self.item.state == "done"
        del_file = menu.addAction("Удалить файл с диска") if file_exists else None
        del_entry = menu.addAction("Убрать из списка")
        action = menu.exec(
            self.delete_btn.mapToGlobal(self.delete_btn.rect().bottomLeft())
        )
        if action is None:
            return
        if action == del_file:
            reply = QMessageBox.question(
                self, "Удаление файла",
                f"Удалить файл «{self.item.name}» с диска?\nЭто действие необратимо.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
            self.manager.remove(self.item, delete_file=True)
        elif action == del_entry:
            self.manager.remove(self.item)

    def mouseDoubleClickEvent(self, event):
        if self.item.state == "done":
            self._on_open()
        super().mouseDoubleClickEvent(event)

    def _elide(self):
        fm = self.name_label.fontMetrics()
        w = max(self.name_label.width(), 50)
        self.name_label.setText(
            fm.elidedText(self._full_name, Qt.TextElideMode.ElideMiddle, w)
        )

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._elide()

    def refresh(self):
        it = self.item
        self._full_name = it.name
        self.name_label.setToolTip(f"{it.name}\n{it.url}")
        self._elide()

        active = it.active
        self.bar.setVisible(active)
        self.pause_btn.setVisible(active)
        self.cancel_btn.setVisible(active)
        self.open_btn.setVisible(it.state == "done")
        self.folder_btn.setVisible(active or it.state == "done")
        self.delete_btn.setVisible(not active)

        if active:
            if it.total > 0:
                self.bar.setRange(0, 1000)
                self.bar.setValue(int(it.received * 1000 / it.total))
            else:
                self.bar.setRange(0, 0)
            self.pause_btn.setIcon(
                self._icon_play if it.state == "paused" else self._icon_pause
            )
            self.pause_btn.setToolTip(
                "Продолжить" if it.state == "paused" else "Приостановить"
            )

        started = datetime.fromtimestamp(it.started).strftime("%H:%M")
        host = urlparse(it.url).hostname or ""

        if it.state == "progress":
            if it.total > 0:
                parts = [f"{fmt_size(it.received)} из {fmt_size(it.total)}"]
            else:
                parts = [fmt_size(it.received)]
            if it.speed > 0:
                parts.append(fmt_speed(it.speed))
                if it.total > it.received:
                    parts.append(
                        "осталось " + fmt_eta((it.total - it.received) / it.speed)
                    )
            else:
                parts.append("ожидание данных…")
            parts.append(f"начата в {started}")
            text = " — ".join(parts)
        elif it.state == "paused":
            size = (
                f"{fmt_size(it.received)} из {fmt_size(it.total)}"
                if it.total > 0 else fmt_size(it.received)
            )
            text = f"Приостановлено — {size} — начата в {started}"
        elif it.state == "done":
            size = it.total if it.total > 0 else it.received
            text = f"{fmt_size(size)} — {host} — {fmt_when(it.finished or it.started)}"
            if not os.path.exists(it.path):
                text += " — файл удалён или перемещён"
                self.open_btn.setEnabled(False)
                self.folder_btn.setEnabled(True)
            else:
                self.open_btn.setEnabled(True)
        elif it.state == "cancelled":
            text = f"Отменено — {fmt_size(it.received)} — {fmt_when(it.finished or it.started)}"
        else:
            text = "Ошибка загрузки" + (f": {it.error}" if it.error else "")
            text += f" — {fmt_when(it.finished or it.started)}"
        self.status_label.setText(text)


class DownloadsDialog(QDialog):
    def __init__(self, manager):
        super().__init__(None)
        self.manager = manager
        self.colors = manager.colors_fn()
        self.rows = {}

        self.setWindowTitle("Загрузки — FurryBrowser")
        self.resize(1020, 560)
        self.setStyleSheet(manager.style_fn(self.colors))
        self.setWindowIcon(_app_icon())

        c = self.colors

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        left = QWidget()
        root.addWidget(left, 1)

        layout = QVBoxLayout(left)
        layout.setContentsMargins(16, 14, 16, 10)
        layout.setSpacing(10)

        top = QHBoxLayout()
        title = QLabel("Загрузки")
        title.setStyleSheet(f"font-size: 18px; font-weight: bold; color: {c['accent']};")
        top.addWidget(title)

        self.clear_btn = QPushButton("Очистить загрузки")
        self.clear_btn.setStyleSheet(
            f"QPushButton {{ background-color: {c['bg_input']}; color: {c['text']};"
            f" border: 1px solid {c['border']}; border-radius: 8px; padding: 6px 12px;"
            f" font-weight: normal; }}"
            f"QPushButton:hover {{ background-color: {c['hover']}; }}"
        )
        self.clear_btn.clicked.connect(self._on_clear)
        top.addWidget(self.clear_btn)
        top.addStretch(1)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Поиск в загрузках")
        self.search.setClearButtonEnabled(True)
        self.search.setMinimumWidth(240)
        self.search.textChanged.connect(self._apply_filter)
        top.addWidget(self.search)
        layout.addLayout(top)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; }")
        holder = QWidget()
        holder.setStyleSheet("background: transparent;")
        self.rows_layout = QVBoxLayout(holder)
        self.rows_layout.setContentsMargins(0, 0, 4, 0)
        self.rows_layout.setSpacing(8)

        self.empty_label = QLabel("Нет загрузок")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_label.setStyleSheet(f"color: {c['text_muted']}; font-size: 14px;")
        self.rows_layout.addWidget(self.empty_label)
        self.rows_layout.addStretch(1)
        self.scroll.setWidget(holder)
        layout.addWidget(self.scroll, 1)

        self.status = QLabel()
        self.status.setStyleSheet(
            f"color: {c['text_muted']}; font-size: 12px;"
            f" border-top: 1px solid {c['border']}; padding-top: 6px;"
        )
        layout.addWidget(self.status)

        art_path = ASSETS_DIR / "art4.png"
        if art_path.exists():
            pm = QPixmap(str(art_path)).scaled(
                280, 420,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            art_label = QLabel()
            art_label.setPixmap(pm)
            art_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            art_label.setContentsMargins(16, 16, 16, 16)
            art_label.setStyleSheet(
                f"background-color: {c['bg_alt']};"
                f" border-left: 1px solid {c['border']};"
            )
            root.addWidget(art_label)

        for item in reversed(manager.items):
            self._add_row(item)
        manager.item_added.connect(lambda it: self._add_row(it))
        manager.item_removed.connect(self._remove_row)
        manager.updated.connect(self._update_status)
        self._update_status()

    def _add_row(self, item):
        row = DownloadRow(item, self.manager, self.colors)
        self.rows[item] = row
        self.rows_layout.insertWidget(1, row)
        self._apply_filter()
        self._update_status()

    def _remove_row(self, item):
        row = self.rows.pop(item, None)
        if row is not None:
            self.rows_layout.removeWidget(row)
            row.deleteLater()
        self._update_status()

    def _apply_filter(self, *_):
        q = self.search.text().strip().lower()
        visible = 0
        for item, row in self.rows.items():
            ok = not q or q in item.name.lower() or q in item.url.lower()
            row.setVisible(ok)
            visible += ok
        self.empty_label.setVisible(visible == 0)
        self.empty_label.setText("Нет загрузок" if not self.rows else "Ничего не найдено")

    def _update_status(self):
        items = self.manager.items
        active = [i for i in items if i.active]
        if active:
            speed = sum(i.speed for i in active)
            text = f"Активных загрузок: {len(active)}"
            if speed > 0:
                text += f" — общая скорость {fmt_speed(speed)}"
            text += f" — всего в списке: {len(items)}"
        else:
            text = f"Всего загрузок: {len(items)}"
        self.status.setText(text)
        self.clear_btn.setEnabled(any(not i.active for i in items))

    def _on_clear(self):
        self.manager.clear_finished()

    def showEvent(self, event):
        for row in self.rows.values():
            row.refresh()
        self._apply_filter()
        super().showEvent(event)


class BaseWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.parent_window = parent
        self.setStyleSheet("background: transparent;")

    def mouseMoveEvent(self, event):
        if self.parent_window:
            self.parent_window._handle_mouse_move(event)
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event):
        if self.parent_window and self.parent_window._handle_mouse_press(event):
            return
        super().mousePressEvent(event)

    def leaveEvent(self, event):
        if self.parent_window:
            self.parent_window.unsetCursor()
        super().leaveEvent(event)


class CustomWebEngineView(QWebEngineView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background: transparent;")

    def _apply_menu_style(self, menu, colors):
        palette = menu.palette()
        palette.setColor(QPalette.ColorRole.Window, QColor(colors["bg"]))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(colors["text"]))
        palette.setColor(QPalette.ColorRole.Base, QColor(colors["bg"]))
        palette.setColor(QPalette.ColorRole.Text, QColor(colors["text"]))
        palette.setColor(QPalette.ColorRole.Button, QColor(colors["bg"]))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(colors["text"]))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(colors["accent"]))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor("#FFFFFF"))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(colors["bg"]))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(colors["text"]))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(colors["text_muted"]))
        palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(colors["text_muted"]))
        menu.setPalette(palette)

        menu.setStyleSheet(get_global_style(colors) + f"""
            QMenu {{
                background-color: {colors['bg']};
                border: 1px solid {colors['border']};
                border-radius: 8px;
                padding: 6px;
                color: {colors['text']};
            }}
            QMenu::item {{
                padding: 8px 24px 8px 12px;
                border-radius: 4px;
                color: {colors['text']};
                background-color: transparent;
            }}
            QMenu::item:selected {{
                background-color: {colors['accent']};
                color: #FFFFFF;
            }}
            QMenu::item:disabled {{
                color: {colors['text_muted']};
            }}
            QMenu::separator {{
                height: 1px;
                background-color: {colors['border']};
                margin: 4px 8px;
            }}
            QMenu::indicator {{
                width: 14px;
                height: 14px;
            }}
        """)

        for action in menu.actions():
            submenu = action.menu()
            if submenu:
                self._apply_menu_style(submenu, colors)

    def contextMenuEvent(self, event):
        try:
            menu = self.createStandardContextMenu()
        except (AttributeError, TypeError, RuntimeError):
            menu = None

        if menu is None:
            super().contextMenuEvent(event)
            return

        self._apply_menu_style(menu, get_theme_colors())

        window = self.window()
        if isinstance(window, BrowserWindow):
            try:
                page_url = self.url().toString()
            except (RuntimeError, AttributeError):
                page_url = ""
            if (
                page_url
                and page_url != "about:blank"
                and not page_url.startswith("furrybrowser:")
            ):
                menu.addSeparator()
                marked = _find_bookmark(page_url) is not None
                action = menu.addAction(
                    "Удалить страницу из закладок" if marked
                    else "Добавить страницу в закладки"
                )
                action.triggered.connect(
                    lambda checked=False, w=window, b=self: w.toggle_bookmark(b)
                )

        menu.exec(event.globalPos())


class SplashScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.colors = get_theme_colors()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.SplashScreen
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(450, 550)
        self.setWindowIcon(_app_icon())

        self.container = QWidget(self)
        self.container.setGeometry(0, 0, 450, 550)
        self.container.setStyleSheet(
            f"QWidget {{ background-color: {self.colors['bg']}; border-radius: 20px; }}"
        )

        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(self.colors["shadow"])
        shadow.setOffset(0, 5)
        self.container.setGraphicsEffect(shadow)

        layout = QVBoxLayout(self.container)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(15)

        self.image_label = QLabel()
        image_path = ASSETS_DIR / "about_art.png"
        if image_path.exists():
            pixmap = QPixmap(str(image_path))
            pixmap = pixmap.scaled(
                350, 350,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            self.image_label.setPixmap(pixmap)
        else:
            self.image_label.setPixmap(_icon_pixmap("paw", self.colors["accent"], 150))

        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.title_label = QLabel("FurryBrowser")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet(f"""
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 36px;
            font-weight: 900;
            color: {self.colors['accent']};
            margin-top: 10px;
        """)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(12)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid {self.colors['border']};
                border-radius: 6px;
                background-color: {self.colors['bg_input']};
            }}
            QProgressBar::chunk {{
                border-radius: 4px;
                background-color: {self.colors['accent']};
            }}
        """)

        layout.addWidget(self.image_label)
        layout.addWidget(self.title_label)
        layout.addStretch()
        layout.addWidget(self.progress_bar)

        self.current_value = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_progress)
        self.timer.start(30)

    def update_progress(self):
        self.current_value += 2
        self.progress_bar.setValue(self.current_value)
        if self.current_value >= 100:
            self.timer.stop()

    def center_on_screen(self):
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)


class CustomTitleBar(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.colors = get_theme_colors()
        c = self.colors
        self.setFixedHeight(40)
        self.setStyleSheet("background-color: transparent;")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 10, 0)
        layout.setSpacing(8)

        self.menu_button = QToolButton()
        self.menu_button.setIcon(_make_icon("menu", c["text"], 18, c["accent"]))
        self.menu_button.setIconSize(QSize(18, 18))
        self.menu_button.setToolTip("Меню")
        self.menu_button.setStyleSheet(
            f"QToolButton {{ padding: 4px 8px; border-radius: 6px; }}"
            f"QToolButton:hover {{ background-color: {c['hover']}; }}"
        )
        self.menu_button.clicked.connect(self.parent._show_menu)

        self.icon_label = QLabel()
        self.icon_label.setPixmap(_app_icon().pixmap(QSize(20, 20)))

        self.title_label = QLabel("FurryBrowser")
        self.title_label.setStyleSheet(
            f"font-weight: bold; color: {c['text']}; font-size: 14px;"
        )
        self.title_label.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        self.title_label.setMinimumWidth(0)
        self._full_title = "FurryBrowser"

        layout.addWidget(self.menu_button)
        layout.addWidget(self.icon_label)
        layout.addWidget(self.title_label, 1)

        btn_style = f"""
            QToolButton {{ background-color: transparent; border: none;
                padding: 0px; margin: 0px; border-radius: 6px; }}
            QToolButton:hover {{ background-color: {c['hover']}; }}
            QToolButton:pressed {{ background-color: {c['pressed']}; }}
        """
        close_style = """
            QToolButton { background-color: transparent; border: none;
                padding: 0px; margin: 0px; border-radius: 6px; }
            QToolButton:hover { background-color: #FF5C5C; }
            QToolButton:pressed { background-color: #E04B4B; }
        """

        def make_btn(icon, tip, style, slot):
            b = QToolButton()
            b.setIcon(icon)
            b.setIconSize(QSize(16, 16))
            b.setToolTip(tip)
            b.setFixedSize(30, 30)
            b.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            b.setStyleSheet(style)
            b.clicked.connect(slot)
            return b

        self._icon_max = _make_icon("maximize", c["text"], 16)
        self._icon_restore = _make_icon("restore", c["text"], 16)

        self.min_btn = make_btn(_make_icon("minimize", c["text"], 16),
                                "Свернуть", btn_style, self.parent.showMinimized)
        self.max_btn = make_btn(self._icon_max, "Развернуть", btn_style, self.toggle_max)
        self.close_btn = make_btn(_make_icon("close", c["text"], 16, "#FFFFFF"),
                                  "Закрыть", close_style, self.parent.close)

        layout.addWidget(self.min_btn)
        layout.addWidget(self.max_btn)
        layout.addWidget(self.close_btn)

    def set_title(self, text):
        self._full_title = text
        self.title_label.setToolTip(text)
        self._elide()

    def _elide(self):
        fm = self.title_label.fontMetrics()
        w = max(self.title_label.width(), 50)
        self.title_label.setText(
            fm.elidedText(self._full_title, Qt.TextElideMode.ElideRight, w)
        )

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._elide()

    def update_max_icon(self, maximized):
        self.max_btn.setIcon(self._icon_restore if maximized else self._icon_max)
        self.max_btn.setToolTip("Свернуть в окно" if maximized else "Развернуть")

    def toggle_max(self):
        if self.parent.isMaximized():
            self.parent.showNormal()
        else:
            self.parent.showMaximized()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.parent.windowHandle().startSystemMove()

    def mouseDoubleClickEvent(self, event):
        self.toggle_max()


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.setWindowTitle("Настройки — FurryBrowser")
        self.setWindowIcon(_app_icon())
        self.resize(1050, 900)
        self.settings = load_settings()
        self._build_ui()
        self._load_from_settings()

    def _build_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)

        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setSpacing(12)
        left_layout.setContentsMargins(20, 20, 20, 16)

        grp_startup = QGroupBox("Запуск")
        v = QVBoxLayout(grp_startup)
        self.open_tabs_cb = QCheckBox("Открывать предыдущие окна и вкладки")
        v.addWidget(self.open_tabs_cb)
        hint = QLabel("При следующем запуске браузер восстановит все окна и их вкладки.")
        hint.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 12px;")
        hint.setWordWrap(True)
        v.addWidget(hint)
        left_layout.addWidget(grp_startup)

        grp_home = QGroupBox("Домашняя страница")
        v = QVBoxLayout(grp_home)
        self.home_edit = QLineEdit()
        self.home_edit.setPlaceholderText(f"Например, {DEFAULT_HOME_URL}")
        v.addWidget(self.home_edit)
        left_layout.addWidget(grp_home)

        grp_bookmarks = QGroupBox("Закладки")
        v = QVBoxLayout(grp_bookmarks)
        self.bookmarks_bar_cb = QCheckBox("Показывать панель закладок")
        v.addWidget(self.bookmarks_bar_cb)
        bookmarks_hint = QLabel(
            "Ctrl+D — добавить текущую страницу в закладки, "
            "Ctrl+Shift+O — менеджер закладок, "
            "Ctrl+Shift+B — показать или скрыть панель закладок."
        )
        bookmarks_hint.setStyleSheet(
            f"color: {self.colors['text_muted']}; font-size: 12px;"
        )
        bookmarks_hint.setWordWrap(True)
        v.addWidget(bookmarks_hint)
        left_layout.addWidget(grp_bookmarks)

        grp_default = QGroupBox("Поисковая система по умолчанию")
        v = QVBoxLayout(grp_default)
        self.default_combo = QComboBox()
        self.default_combo.setStyleSheet(
            f"QComboBox {{ padding: 6px; border: 1px solid {self.colors['border']};"
            f" border-radius: 8px; background: {self.colors['bg_input']}; color: {self.colors['text']}; }}"
        )
        self.default_combo.currentIndexChanged.connect(self._on_default_changed)
        v.addWidget(self.default_combo)
        left_layout.addWidget(grp_default)

        grp_engines = QGroupBox("Поисковые системы")
        v = QVBoxLayout(grp_engines)
        self.engines_list = QListWidget()
        self.engines_list.setMinimumHeight(150)
        v.addWidget(self.engines_list)

        add_row = QHBoxLayout()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Название")
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText("URL с {query}")
        self.add_btn = QPushButton("Добавить")
        self.add_btn.clicked.connect(self._on_add_engine)
        add_row.addWidget(self.name_edit, 1)
        add_row.addWidget(self.url_edit, 2)
        add_row.addWidget(self.add_btn)
        v.addLayout(add_row)
        left_layout.addWidget(grp_engines, 1)

        grp_addr = QGroupBox("Адресная строка")
        v = QVBoxLayout(grp_addr)
        v.addWidget(QLabel("Показывать в подсказках:"))
        self.history_cb = QCheckBox("История посещений")
        self.open_tabs_addr_cb = QCheckBox("Открытые вкладки")
        self.bookmarks_addr_cb = QCheckBox("Закладки")
        v.addWidget(self.history_cb)
        v.addWidget(self.open_tabs_addr_cb)
        v.addWidget(self.bookmarks_addr_cb)
        left_layout.addWidget(grp_addr)

        grp_geo = QGroupBox("Геолокация")
        v = QVBoxLayout(grp_geo)
        self.geo_cb = QCheckBox(
            "Определять приблизительное местоположение по IP, "
            "если системная геолокация недоступна"
        )
        v.addWidget(self.geo_cb)
        geo_hint = QLabel(
            "Сайты каждый раз спрашивают разрешение — выбор не запоминается. "
            "Запрос к сервису определения местоположения (ipwho.is / ipapi.co) "
            "отправляется только после того, как вы разрешили доступ какому-либо "
            "сайту. Точность — уровня города."
        )
        geo_hint.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 12px;")
        geo_hint.setWordWrap(True)
        v.addWidget(geo_hint)
        left_layout.addWidget(grp_geo)

        grp_notif = QGroupBox("Уведомления")
        v = QVBoxLayout(grp_notif)
        self.notif_cb = QCheckBox("Разрешить сайтам показывать уведомления")
        v.addWidget(self.notif_cb)
        notif_hint = QLabel(
            "Сайт каждый раз запрашивает разрешение — выбор не запоминается. "
            "Если отключить пункт, запросы уведомлений будут отклоняться "
            "автоматически."
        )
        notif_hint.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 12px;")
        notif_hint.setWordWrap(True)
        v.addWidget(notif_hint)
        left_layout.addWidget(grp_notif)

        grp_data = QGroupBox("Данные браузера")
        v = QVBoxLayout(grp_data)
        data_hint = QLabel(
            "Удалить историю, cookies, кэш, данные сайтов, сессию и другие "
            "сохраняемые данные можно через главное меню (кнопка слева в "
            "заголовке окна) → «Очистить данные…» или по Ctrl+Shift+Del."
        )
        data_hint.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 12px;")
        data_hint.setWordWrap(True)
        v.addWidget(data_hint)
        self.clear_data_btn = QPushButton("Очистить данные…")
        self.clear_data_btn.setStyleSheet(
            f"background-color: {self.colors['bg_input']}; color: {self.colors['text']};"
            f" border: 1px solid {self.colors['border']};"
        )
        self.clear_data_btn.clicked.connect(self._on_clear_data)
        v.addWidget(self.clear_data_btn)
        left_layout.addWidget(grp_data)

        right_widget = QWidget()
        right_widget.setStyleSheet(
            f"background-color: {self.colors['bg_alt']}; border-left: 1px solid {self.colors['border']};"
        )
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(20, 20, 20, 20)

        self.img_label = QLabel()
        art_path = ASSETS_DIR / "art.png"
        if art_path.exists():
            pixmap = QPixmap(str(art_path))
            pixmap = pixmap.scaled(
                400, 700,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            self.img_label.setPixmap(pixmap)
        else:
            self.img_label.setText("Место для вашей картинки\n(art.png)")
            self.img_label.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 16px;")

        self.img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        right_layout.addWidget(self.img_label)

        bottom_widget = QWidget()
        bottom_layout = QHBoxLayout(bottom_widget)
        bottom_layout.setContentsMargins(20, 10, 20, 20)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        btns.button(QDialogButtonBox.StandardButton.Save).setText("Сохранить")
        btns.button(QDialogButtonBox.StandardButton.Cancel).setText("Отмена")
        btns.button(QDialogButtonBox.StandardButton.Cancel).setStyleSheet(
            f"background-color: {self.colors['bg_input']}; color: {self.colors['text']};"
        )
        btns.accepted.connect(self._on_save)
        btns.rejected.connect(self.reject)

        bottom_layout.addStretch()
        bottom_layout.addWidget(btns)

        main_vbox = QVBoxLayout()
        main_vbox.setContentsMargins(0, 0, 0, 0)
        main_vbox.setSpacing(0)

        content_layout = QHBoxLayout()
        content_layout.addWidget(left_widget, 2)
        content_layout.addWidget(right_widget, 1)

        main_vbox.addLayout(content_layout, 1)
        main_vbox.addWidget(bottom_widget)

        container = QWidget()
        container.setLayout(main_vbox)
        main_layout.addWidget(container)

    def _on_clear_data(self):
        dlg = ClearDataDialog(self)
        dlg.exec()

    def _load_from_settings(self):
        self.open_tabs_cb.setChecked(bool(self.settings.get("open_previous_tabs")))
        self.home_edit.setText(self.settings.get("home_page") or "")
        self.bookmarks_bar_cb.setChecked(bool(self.settings.get("bookmarks_bar", True)))
        addr = self.settings.get("address_bar") or {}
        self.history_cb.setChecked(bool(addr.get("history", True)))
        self.open_tabs_addr_cb.setChecked(bool(addr.get("open_tabs", True)))
        self.bookmarks_addr_cb.setChecked(bool(addr.get("bookmarks", True)))
        geo = self.settings.get("geolocation") or {}
        self.geo_cb.setChecked(bool(geo.get("ip_fallback", True)))
        notif = self.settings.get("notifications") or {}
        self.notif_cb.setChecked(bool(notif.get("enabled", True)))
        self._refresh_default_combo()
        self._refresh_engines_list()

    def _refresh_default_combo(self):
        engines = self.settings.get("search_engines", [])
        current_id = self.settings.get("default_search_engine", "nex")
        self.default_combo.blockSignals(True)
        self.default_combo.clear()
        target_index = 0
        for idx, e in enumerate(engines):
            self.default_combo.addItem(e.get("name", e.get("id", "?")), e.get("id"))
            if e.get("id") == current_id:
                target_index = idx
        if engines:
            self.default_combo.setCurrentIndex(target_index)
        self.default_combo.blockSignals(False)

    def _refresh_engines_list(self):
        self.engines_list.clear()
        engines = self.settings.get("search_engines", [])
        default_id = self.settings.get("default_search_engine")
        for e in engines:
            name = e.get("name", "?")
            url = e.get("url", "")
            badge = "  [по умолчанию]" if e.get("id") == default_id else ""
            item = QListWidgetItem(f"{name}{badge}\n{url}")
            item.setData(Qt.ItemDataRole.UserRole, e.get("id"))
            self.engines_list.addItem(item)

    def _on_default_changed(self, _index):
        engine_id = self.default_combo.currentData()
        if engine_id:
            self.settings["default_search_engine"] = engine_id
            self._refresh_engines_list()

    def _on_add_engine(self):
        name = self.name_edit.text().strip()
        url = self.url_edit.text().strip()
        if not name or not url:
            QMessageBox.warning(self, "Ошибка", "Заполните название и URL.")
            return
        if "{query}" not in url:
            QMessageBox.warning(self, "Ошибка", "URL должен содержать подстановку {query}.")
            return
        new_id = f"engine_{int(datetime.now().timestamp() * 1000)}"
        engines = self.settings.setdefault("search_engines", [])
        engines.append({"id": new_id, "name": name, "url": url})
        self.name_edit.clear()
        self.url_edit.clear()
        self._refresh_default_combo()
        self._refresh_engines_list()

    def _apply_to_settings(self):
        self.settings["open_previous_tabs"] = self.open_tabs_cb.isChecked()
        engine_id = self.default_combo.currentData()
        if engine_id:
            self.settings["default_search_engine"] = engine_id

        home = self.home_edit.text().strip()
        if home and not home.startswith(("http://", "https://", "ftp://", "file://")):
            home = "https://" + home
        self.settings["home_page"] = home

        self.settings["address_bar"] = {
            "history": self.history_cb.isChecked(),
            "open_tabs": self.open_tabs_addr_cb.isChecked(),
            "bookmarks": self.bookmarks_addr_cb.isChecked(),
        }
        self.settings["bookmarks_bar"] = self.bookmarks_bar_cb.isChecked()
        self.settings["geolocation"] = {
            "ip_fallback": self.geo_cb.isChecked(),
        }
        self.settings["notifications"] = {
            "enabled": self.notif_cb.isChecked(),
        }

    def _after_save(self):
        if _GEO is not None:
            _GEO.reconfigure()
        if _NOTIFY is not None and not self.notif_cb.isChecked():
            _NOTIFY.close_all()
        _refresh_bookmark_ui()

    def _on_save(self):
        self._apply_to_settings()
        if save_settings(self.settings):
            self._after_save()
            self.accept()
        else:
            QMessageBox.critical(self, "Ошибка", "Не удалось сохранить настройки.")

    def closeEvent(self, event):
        self._apply_to_settings()
        save_settings(self.settings)
        _refresh_bookmark_ui()
        super().closeEvent(event)


class ClearDataDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.setWindowTitle("Очистить данные — FurryBrowser")
        self.setMinimumWidth(560)
        self.setStyleSheet(get_global_style(self.colors))
        self.setWindowIcon(_app_icon())

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        left = QWidget()
        root.addWidget(left, 1)
        layout = QVBoxLayout(left)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        title = QLabel("Удаление данных браузера")
        title.setStyleSheet(
            f"font-size: 18px; font-weight: bold; color: {self.colors['accent']};"
        )
        layout.addWidget(title)

        hint = QLabel(
            "Выберите категории данных, которые нужно удалить. Действие необратимо.\n"
            "Cookies и HTTP-кэш применяются сразу; полное удаление LocalStorage, "
            "IndexedDB и Service Workers из памяти Chromium произойдёт после "
            "перезапуска браузера."
        )
        hint.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 12px;")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addSpacing(4)

        self.cb_all = QCheckBox("Выбрать всё")
        self.cb_all.toggled.connect(self._toggle_all)
        layout.addWidget(self.cb_all)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"background-color: {self.colors['border']}; max-height: 1px; border: none;")
        layout.addWidget(sep)

        self.cb_history = QCheckBox("История посещений")
        self.cb_cookies = QCheckBox("Cookies")
        self.cb_cache = QCheckBox("HTTP-кэш")
        self.cb_site_data = QCheckBox("Данные сайтов (LocalStorage, IndexedDB, Service Workers, сессии)")
        self.cb_session = QCheckBox("Сохранённые вкладки (сессия)")
        self.cb_window_state = QCheckBox("Положение и размер окна")
        self.cb_zoom = QCheckBox("Уровни масштаба сайтов")
        self.cb_settings = QCheckBox("Настройки браузера (сброс к умолчанию)")

        self._items = [
            self.cb_history, self.cb_cookies, self.cb_cache, self.cb_site_data,
            self.cb_session, self.cb_window_state, self.cb_zoom, self.cb_settings,
        ]
        for cb in self._items:
            layout.addWidget(cb)
            cb.toggled.connect(self._sync_all)

        layout.addSpacing(8)

        data_path_label = QLabel(f"Папка данных: {SETTINGS_DIR}")
        data_path_label.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 11px;")
        data_path_label.setWordWrap(True)
        layout.addWidget(data_path_label)
        layout.addSpacing(4)

        btn_row = QHBoxLayout()
        self.clear_btn = QPushButton("Удалить выбранное")
        self.clear_btn.setStyleSheet(
            "background-color: #FF5C5C; color: white; border: none;"
            " border-radius: 8px; padding: 8px 16px; font-weight: bold;"
        )
        self.clear_btn.clicked.connect(self._on_clear)

        cancel_btn = QPushButton("Отмена")
        cancel_btn.setStyleSheet(
            f"background-color: {self.colors['bg_input']}; color: {self.colors['text']};"
            f" border: 1px solid {self.colors['border']};"
        )
        cancel_btn.clicked.connect(self.reject)

        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(self.clear_btn)
        layout.addLayout(btn_row)

        art_path = ASSETS_DIR / "art2.png"
        if art_path.exists():
            pm = QPixmap(str(art_path)).scaled(
                300, 450,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            art_label = QLabel()
            art_label.setPixmap(pm)
            art_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            art_label.setContentsMargins(16, 16, 16, 16)
            art_label.setStyleSheet(
                f"background-color: {self.colors['bg_alt']};"
                f" border-left: 1px solid {self.colors['border']};"
            )
            root.addWidget(art_label)

    def _toggle_all(self, checked):
        for cb in self._items:
            cb.blockSignals(True)
            cb.setChecked(checked)
            cb.blockSignals(False)

    def _sync_all(self):
        all_checked = all(cb.isChecked() for cb in self._items)
        self.cb_all.blockSignals(True)
        self.cb_all.setChecked(all_checked)
        self.cb_all.blockSignals(False)

    def _selected_labels(self):
        labels = []
        if self.cb_history.isChecked(): labels.append("История посещений")
        if self.cb_cookies.isChecked(): labels.append("Cookies")
        if self.cb_cache.isChecked(): labels.append("HTTP-кэш")
        if self.cb_site_data.isChecked(): labels.append("Данные сайтов (LocalStorage, IndexedDB, SW)")
        if self.cb_session.isChecked(): labels.append("Сохранённые вкладки")
        if self.cb_window_state.isChecked(): labels.append("Положение/размер окна")
        if self.cb_zoom.isChecked(): labels.append("Уровни масштаба")
        if self.cb_settings.isChecked(): labels.append("Настройки (сброс к умолчанию)")
        return labels

    def _on_clear(self):
        selected = self._selected_labels()
        if not selected:
            QMessageBox.information(self, "Ничего не выбрано",
                                    "Отметьте хотя бы один пункт для удаления.")
            return

        reply = QMessageBox.question(
            self, "Подтверждение удаления",
            "Будут удалены следующие данные:\n\n• " + "\n• ".join(selected) +
            "\n\nЭто действие необратимо. Продолжить?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        errors = self._perform_clear()

        msg = "Выбранные данные удалены."
        if errors:
            msg += (
                "\n\nНекоторые данные не удалось удалить сразу (файлы заняты "
                "работающим Chromium). Они будут удалены после перезапуска браузера:\n• "
                + "\n• ".join(errors[:10])
            )
        QMessageBox.information(self, "Готово", msg)
        self.accept()

    def _perform_clear(self):
        errors = []

        if self.cb_history.isChecked():
            try:
                _HISTORY.clear()
                _save_history()
            except Exception as e:
                errors.append(f"История: {e}")

        if self.cb_cookies.isChecked():
            try:
                _get_persistent_profile().cookieStore().deleteAllCookies()
            except Exception as e:
                errors.append(f"Cookies: {e}")
            for name in ("Cookies", "Cookies-journal", "Cookies-wal", "Cookies-shm"):
                p = PROFILE_DIR / name
                if p.exists():
                    try:
                        p.unlink()
                    except Exception:
                        pass

        if self.cb_cache.isChecked():
            try:
                _get_persistent_profile().clearHttpCache()
            except Exception as e:
                errors.append(f"HTTP-кэш (API): {e}")
            try:
                if CACHE_DIR.exists():
                    for item in list(CACHE_DIR.iterdir()):
                        try:
                            if item.is_dir():
                                shutil.rmtree(item, ignore_errors=True)
                            else:
                                item.unlink()
                        except Exception:
                            pass
            except Exception as e:
                errors.append(f"Кэш (файлы): {e}")

        if self.cb_site_data.isChecked():
            targets = [
                "Local Storage", "Session Storage", "IndexedDB",
                "Service Worker", "shared_proto_db", "databases",
                "File System", "WebStorage", "blob_storage",
                "Sync Data", "Storage", "DawnGraphiteCache",
                "DawnWebGPUCache", "GPUCache", "Code Cache",
            ]
            for name in targets:
                p = PROFILE_DIR / name
                if p.exists():
                    try:
                        shutil.rmtree(p, ignore_errors=True)
                    except Exception:
                        pass
            for pattern in ("*.log", "*.ldb", "*.sst", "LOG", "LOCK", "MANIFEST-*"):
                for f in PROFILE_DIR.glob(pattern):
                    try:
                        if f.is_file():
                            f.unlink()
                    except Exception:
                        pass

        if self.cb_session.isChecked():
            try:
                if SESSION_FILE.exists():
                    SESSION_FILE.unlink()
            except Exception as e:
                errors.append(f"Сессия: {e}")

        if self.cb_window_state.isChecked():
            try:
                if WINDOW_STATE_FILE.exists():
                    WINDOW_STATE_FILE.unlink()
            except Exception as e:
                errors.append(f"Состояние окна: {e}")

        if self.cb_zoom.isChecked():
            try:
                _ZOOM_LEVELS.clear()
                _save_zoom_levels()
                for w in list(_WINDOWS):
                    try:
                        for i in range(w.tabs.count()):
                            b = w.tabs.widget(i)
                            if b and b.page():
                                b.page().setZoomFactor(1.0)
                    except Exception:
                        pass
            except Exception as e:
                errors.append(f"Масштаб: {e}")

        if self.cb_settings.isChecked():
            try:
                if SETTINGS_FILE.exists():
                    SETTINGS_FILE.unlink()
                save_settings(copy.deepcopy(DEFAULT_SETTINGS))
                if _GEO is not None:
                    _GEO.reconfigure()
            except Exception as e:
                errors.append(f"Настройки: {e}")

        return errors


class FindBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        c = self.colors
        self.setObjectName("FindBar")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setVisible(False)
        self.setStyleSheet(
            f"QWidget#FindBar {{ background-color: {c['bg']};"
            f" border-bottom: 1px solid {c['border']}; }}"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 4, 8, 4)
        lay.setSpacing(6)

        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Найти на странице...")
        self.edit.setClearButtonEnabled(True)

        self.status_label = QLabel("")
        self.status_label.setMinimumWidth(100)

        def mk(kind, tip):
            b = QToolButton()
            b.setIcon(_make_icon(kind, c["text"], 16, c["accent"]))
            b.setIconSize(QSize(16, 16))
            b.setToolTip(tip)
            return b

        self.prev_btn = mk("up", "Предыдущее")
        self.next_btn = mk("down", "Следующее")
        self.close_btn = mk("close", "Закрыть")

        lay.addWidget(self.edit, 1)
        lay.addWidget(self.status_label)
        lay.addWidget(self.prev_btn)
        lay.addWidget(self.next_btn)
        lay.addWidget(self.close_btn)

    def set_status(self, matches, active):
        if not self.edit.text():
            self.status_label.setText("")
        elif matches == 0:
            self.status_label.setText("Нет совпадений")
        else:
            self.status_label.setText(f"{active} из {matches}")


class HistoryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.setWindowTitle("История")
        self.setWindowIcon(_app_icon())
        self.resize(1080, 560)

        self.setStyleSheet(f"""
            QDialog {{
                background-color: {self.colors['bg']};
            }}
            QListWidget {{
                background-color: {self.colors['bg_input']};
                color: {self.colors['text']};
                border: 1px solid {self.colors['border']};
                border-radius: 8px;
                font-size: 14px;
            }}
            QListWidget::item {{
                color: {self.colors['text']};
                padding: 8px;
                border-bottom: 1px solid {self.colors['border']};
            }}
            QListWidget::item:selected {{
                background-color: {self.colors['accent']};
                color: white;
            }}
            QPushButton {{
                background-color: {self.colors['accent']};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #357ABD;
            }}
            QPushButton#clear_btn {{
                background-color: #FF5C5C;
            }}
            QPushButton#clear_btn:hover {{
                background-color: #E04B4B;
            }}
        """)

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        left = QWidget()
        root.addWidget(left, 1)

        layout = QVBoxLayout(left)
        layout.setContentsMargins(16, 14, 16, 12)

        self.list = QListWidget()
        layout.addWidget(self.list)

        row = QHBoxLayout()
        self.clear_btn = QPushButton("Очистить историю")
        self.clear_btn.setObjectName("clear_btn")
        self.close_btn = QPushButton("Закрыть")
        row.addWidget(self.clear_btn)
        row.addStretch()
        row.addWidget(self.close_btn)
        layout.addLayout(row)

        art_path = ASSETS_DIR / "art6.png"
        if art_path.exists():
            pm = QPixmap(str(art_path)).scaled(
                300, 450,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            art_label = QLabel()
            art_label.setPixmap(pm)
            art_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            art_label.setContentsMargins(16, 16, 16, 16)
            art_label.setStyleSheet(
                f"background-color: {self.colors['bg_alt']};"
                f" border-left: 1px solid {self.colors['border']};"
            )
            root.addWidget(art_label)

        self.open_callback = None
        self._refresh()
        self.list.itemDoubleClicked.connect(self._on_open)
        self.clear_btn.clicked.connect(self._on_clear)
        self.close_btn.clicked.connect(self.accept)

    def _refresh(self):
        self.list.clear()
        if not _HISTORY:
            item = QListWidgetItem("История пуста")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.list.addItem(item)
            return
        for url, title, ts in reversed(_HISTORY):
            item = QListWidgetItem(f"{title}\n{url}    — {ts}")
            item.setData(Qt.ItemDataRole.UserRole, url)
            self.list.addItem(item)

    def _on_open(self, item):
        url = item.data(Qt.ItemDataRole.UserRole)
        if url and self.open_callback:
            self.open_callback(QUrl(url))
            self.accept()

    def _on_clear(self):
        _HISTORY.clear()
        _save_history()
        self._refresh()


class BookmarkEditDialog(QDialog):
    def __init__(self, parent=None, bookmark=None, title="", url=""):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.bookmark = bookmark
        self.setWindowTitle("Закладка — FurryBrowser")
        self.setWindowIcon(_app_icon())
        self.setMinimumWidth(520)
        self.setStyleSheet(get_global_style(self.colors))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        heading = QLabel("Изменить закладку" if bookmark is not None else "Добавить закладку")
        heading.setStyleSheet(
            f"font-size: 18px; font-weight: bold; color: {self.colors['accent']};"
        )
        layout.addWidget(heading)

        layout.addSpacing(6)
        layout.addWidget(QLabel("Название"))
        self.title_edit = QLineEdit(title or (bookmark or {}).get("title", ""))
        self.title_edit.setPlaceholderText("Название закладки")
        layout.addWidget(self.title_edit)

        layout.addWidget(QLabel("Адрес"))
        self.url_edit = QLineEdit(url or (bookmark or {}).get("url", ""))
        self.url_edit.setPlaceholderText("https://example.com")
        layout.addWidget(self.url_edit)

        layout.addSpacing(6)
        row = QHBoxLayout()
        row.addStretch()
        cancel_btn = QPushButton("Отмена")
        cancel_btn.setStyleSheet(
            f"background-color: {self.colors['bg_input']}; color: {self.colors['text']};"
            f" border: 1px solid {self.colors['border']};"
        )
        save_btn = QPushButton("Сохранить")
        cancel_btn.clicked.connect(self.reject)
        save_btn.clicked.connect(self._on_save)
        row.addWidget(cancel_btn)
        row.addWidget(save_btn)
        layout.addLayout(row)

        if not self.title_edit.text():
            self.title_edit.setFocus()
        else:
            self.url_edit.setFocus()
            self.url_edit.selectAll()

    def _on_save(self):
        title = self.title_edit.text().strip()
        raw_url = self.url_edit.text().strip()
        if not raw_url:
            QMessageBox.warning(self, "Ошибка", "Введите адрес закладки.")
            return

        if "://" not in raw_url and not raw_url.startswith(
            ("http:", "https:", "ftp:", "file:", "about:")
        ):
            raw_url = "https://" + raw_url

        qurl = QUrl(raw_url)
        if not qurl.isValid() or qurl.scheme().lower() not in (
            "http", "https", "ftp", "file",
        ):
            QMessageBox.warning(self, "Ошибка", "Введите корректный адрес.")
            return

        url = qurl.toString()
        if not title:
            title = url

        existing = _find_bookmark(url)
        if existing is not None and existing is not self.bookmark:
            if self.bookmark is None:
                existing["title"] = title
            else:
                _BOOKMARKS.remove(existing)
        if self.bookmark is not None:
            self.bookmark["url"] = url
            self.bookmark["title"] = title
        elif existing is None:
            _BOOKMARKS.append({
                "url": url,
                "title": title,
                "added": datetime.now().strftime("%Y-%m-%d %H:%M"),
            })

        _save_bookmarks()
        _refresh_bookmark_ui()
        self.accept()


class BookmarksDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.setWindowTitle("Закладки — FurryBrowser")
        self.setWindowIcon(_app_icon())
        self.resize(1080, 600)
        self.open_callback = None
        self.open_new_tab_callback = None

        self.setStyleSheet(f"""
            QDialog {{
                background-color: {self.colors['bg']};
            }}
            QListWidget {{
                background-color: {self.colors['bg_input']};
                color: {self.colors['text']};
                border: 1px solid {self.colors['border']};
                border-radius: 8px;
                font-size: 14px;
            }}
            QListWidget::item {{
                color: {self.colors['text']};
                padding: 8px;
                border-bottom: 1px solid {self.colors['border']};
            }}
            QListWidget::item:selected {{
                background-color: {self.colors['accent']};
                color: white;
            }}
            QPushButton {{
                background-color: {self.colors['accent']};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #357ABD;
            }}
            QPushButton:disabled {{
                background-color: {self.colors['bg_input']};
                color: {self.colors['text_muted']};
            }}
            QPushButton#danger_btn {{
                background-color: #FF5C5C;
            }}
            QPushButton#danger_btn:hover {{
                background-color: #E04B4B;
            }}
        """)

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        left = QWidget()
        root.addWidget(left, 1)

        layout = QVBoxLayout(left)
        layout.setContentsMargins(16, 14, 16, 12)
        layout.setSpacing(10)

        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Поиск по закладкам…")
        self.filter_edit.setClearButtonEnabled(True)
        self.filter_edit.textChanged.connect(self._refresh)
        layout.addWidget(self.filter_edit)

        self.list = QListWidget()
        self.list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.list.itemDoubleClicked.connect(lambda _item: self._on_open(False))
        self.list.itemSelectionChanged.connect(self._update_buttons)
        layout.addWidget(self.list, 1)

        self.status = QLabel()
        self.status.setStyleSheet(f"color: {self.colors['text_muted']}; font-size: 12px;")
        layout.addWidget(self.status)

        row = QHBoxLayout()
        self.open_btn = QPushButton("Открыть")
        self.open_new_btn = QPushButton("В новой вкладке")
        self.edit_btn = QPushButton("Изменить…")
        self.delete_btn = QPushButton("Удалить")
        self.delete_btn.setObjectName("danger_btn")
        self.delete_all_btn = QPushButton("Удалить все")
        self.delete_all_btn.setObjectName("danger_btn")
        self.close_btn = QPushButton("Закрыть")

        self.open_btn.clicked.connect(lambda: self._on_open(False))
        self.open_new_btn.clicked.connect(lambda: self._on_open(True))
        self.edit_btn.clicked.connect(self._on_edit)
        self.delete_btn.clicked.connect(self._on_delete)
        self.delete_all_btn.clicked.connect(self._on_delete_all)
        self.close_btn.clicked.connect(self.accept)

        row.addWidget(self.open_btn)
        row.addWidget(self.open_new_btn)
        row.addWidget(self.edit_btn)
        row.addWidget(self.delete_btn)
        row.addWidget(self.delete_all_btn)
        row.addStretch()
        row.addWidget(self.close_btn)
        layout.addLayout(row)

        art_path = ASSETS_DIR / "art6.png"
        if art_path.exists():
            pm = QPixmap(str(art_path)).scaled(
                300, 450,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            art_label = QLabel()
            art_label.setPixmap(pm)
            art_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            art_label.setContentsMargins(16, 16, 16, 16)
            art_label.setStyleSheet(
                f"background-color: {self.colors['bg_alt']};"
                f" border-left: 1px solid {self.colors['border']};"
            )
            root.addWidget(art_label)

        self._refresh()

    def _refresh(self):
        self.list.clear()
        query = self.filter_edit.text().strip().lower() if hasattr(self, "filter_edit") else ""
        bookmarks = [
            b for b in _BOOKMARKS
            if not query
            or query in (b.get("title") or "").lower()
            or query in (b.get("url") or "").lower()
        ]
        if not bookmarks:
            text = "Закладок пока нет" if not _BOOKMARKS else "Ничего не найдено"
            item = QListWidgetItem(text)
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.list.addItem(item)
        else:
            for bookmark in bookmarks:
                added = f"    — {bookmark['added']}" if bookmark.get("added") else ""
                item = QListWidgetItem(
                    f"{bookmark.get('title') or bookmark['url']}\n"
                    f"{bookmark['url']}{added}"
                )
                item.setData(Qt.ItemDataRole.UserRole, bookmark["url"])
                self.list.addItem(item)

        total = len(_BOOKMARKS)
        shown = len(bookmarks)
        self.status.setText(
            f"Всего закладок: {total}" if shown == total
            else f"Показано: {shown} из {total}"
        )
        self.delete_all_btn.setEnabled(total > 0)
        self._update_buttons()

    def _selected_urls(self):
        urls = []
        for item in self.list.selectedItems():
            url = item.data(Qt.ItemDataRole.UserRole)
            if url:
                urls.append(url)
        return urls

    def _update_buttons(self):
        selected = len(self._selected_urls())
        self.open_btn.setEnabled(selected > 0)
        self.open_new_btn.setEnabled(selected > 0)
        self.edit_btn.setEnabled(selected == 1)
        self.delete_btn.setEnabled(selected > 0)

    def _on_open(self, new_tab):
        urls = self._selected_urls()
        if not urls:
            return
        if new_tab and self.open_new_tab_callback:
            for url in urls:
                self.open_new_tab_callback(QUrl(url))
        elif not new_tab and self.open_callback:
            self.open_callback(QUrl(urls[0]))
        self.accept()

    def _on_edit(self):
        urls = self._selected_urls()
        if len(urls) != 1:
            return
        bookmark = _find_bookmark(urls[0])
        if bookmark is None:
            self._refresh()
            return
        dlg = BookmarkEditDialog(self, bookmark=bookmark)
        dlg.exec()
        self._refresh()

    def _on_delete(self):
        urls = self._selected_urls()
        if not urls:
            return
        answer = QMessageBox.question(
            self,
            "Удаление закладок",
            f"Удалить выбранные закладки ({len(urls)})?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        for url in urls:
            bookmark = _find_bookmark(url)
            if bookmark is not None:
                _BOOKMARKS.remove(bookmark)
        _save_bookmarks()
        _refresh_bookmark_ui()
        self._refresh()

    def _on_delete_all(self):
        if not _BOOKMARKS:
            return
        answer = QMessageBox.question(
            self,
            "Удаление закладок",
            f"Удалить все закладки ({len(_BOOKMARKS)})? Это действие нельзя отменить.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        _BOOKMARKS.clear()
        _save_bookmarks()
        _refresh_bookmark_ui()
        self._refresh()


class BookmarksBar(QWidget):
    TITLE_LIMIT = 28

    def __init__(self, window):
        super().__init__(window)
        self.browser_window = window
        self.colors = window.colors
        self.setObjectName("BookmarksBar")
        self.setFixedHeight(32)
        self.setStyleSheet(
            f"QWidget#BookmarksBar {{ background-color: {self.colors['bg']};"
            f" border-bottom: 1px solid {self.colors['border']}; }}"
            f"QWidget#BookmarksBar QToolButton {{ border: none; border-radius: 6px;"
            f" padding: 3px 8px; color: {self.colors['text']}; background: transparent; }}"
            f"QWidget#BookmarksBar QToolButton:hover {{"
            f" background-color: {self.colors['hover']}; }}"
        )

        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(10, 2, 10, 2)
        self._layout.setSpacing(2)
        self._layout.setAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        )

        self._rebuild_timer = QTimer(self)
        self._rebuild_timer.setSingleShot(True)
        self._rebuild_timer.timeout.connect(self._rebuild)
        self.rebuild()

    def rebuild(self):
        self._rebuild_timer.start(60)

    def _clear(self):
        while self._layout.count():
            item = self._layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _short(self, text, limit=None):
        limit = limit or self.TITLE_LIMIT
        text = (text or "").strip() or "Без названия"
        return text if len(text) <= limit else text[: limit - 1] + "…"

    def _fit_count(self, bookmarks):
        width = self.width()
        if width <= 120:
            return len(bookmarks)
        available = width - 40
        metrics = self.fontMetrics()
        used = 0
        count = 0
        for bookmark in bookmarks:
            label = self._short(bookmark.get("title") or bookmark.get("url"))
            needed = metrics.horizontalAdvance(label) + 36
            if count and used + needed > available:
                break
            used += needed
            count += 1
        return count

    def _make_button(self, bookmark):
        btn = QToolButton()
        btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        btn.setIcon(_make_icon("star", self.colors["accent"], 13))
        btn.setIconSize(QSize(13, 13))
        btn.setText(self._short(bookmark.get("title") or bookmark.get("url")))
        btn.setToolTip(
            f"{bookmark.get('title') or bookmark['url']}\n{bookmark['url']}"
        )
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setAutoRaise(True)
        url = bookmark["url"]
        btn.clicked.connect(lambda: self.browser_window.open_bookmark(url))
        btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        btn.customContextMenuRequested.connect(
            lambda pos, b=btn, u=url: self._show_context_menu(b, pos, u)
        )
        return btn

    def _show_context_menu(self, button, pos, url):
        menu = QMenu(self)
        menu.setStyleSheet(get_global_style(self.colors))
        open_new = menu.addAction("Открыть в новой вкладке")
        edit = menu.addAction("Изменить…")
        delete = menu.addAction("Удалить")
        chosen = menu.exec(button.mapToGlobal(pos))
        if chosen == open_new:
            self.browser_window.add_new_tab(QUrl(url))
        elif chosen == edit:
            self.browser_window.edit_bookmark(url)
        elif chosen == delete:
            remove_bookmark(url)
            _refresh_bookmark_ui()

    def _rebuild(self):
        self._clear()
        bookmarks = list(_BOOKMARKS)
        if not bookmarks:
            label = QLabel("Закладок пока нет — нажмите ☆ в адресной строке")
            label.setStyleSheet(
                f"color: {self.colors['text_muted']}; font-size: 12px;"
            )
            self._layout.addWidget(label)
            self._layout.addStretch(1)
            return

        count = max(1, min(self._fit_count(bookmarks), len(bookmarks)))
        for bookmark in bookmarks[:count]:
            self._layout.addWidget(self._make_button(bookmark))

        rest = bookmarks[count:]
        if rest:
            more_btn = QToolButton()
            more_btn.setText("»")
            more_btn.setToolTip(f"Ещё закладок: {len(rest)}")
            more_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            more_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            menu = QMenu(more_btn)
            menu.setStyleSheet(get_global_style(self.colors))
            for bookmark in rest:
                action = menu.addAction(
                    self._short(bookmark.get("title") or bookmark["url"], 48)
                )
                action.setToolTip(bookmark["url"])
                url = bookmark["url"]
                action.triggered.connect(
                    lambda checked=False, u=url: self.browser_window.open_bookmark(u)
                )
            more_btn.setMenu(menu)
            self._layout.addWidget(more_btn)

        self._layout.addStretch(1)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.rebuild()


class PermissionDialog(QDialog):
    def __init__(self, origin, feature_name, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.setWindowTitle("Запрос доступа — FurryBrowser")
        self.setMinimumWidth(460)
        self.setStyleSheet(get_global_style(self.colors))
        self.setWindowIcon(_app_icon())

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        icon_label = QLabel()
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        if (ASSETS_DIR / "icon.png").exists():
            icon_label.setPixmap(_app_icon().pixmap(QSize(72, 72)))
        else:
            icon_label.setPixmap(_icon_pixmap("lock", self.colors["accent"], 56))
        layout.addWidget(icon_label)

        title = QLabel(f"Разрешить доступ к {feature_name}?")
        title.setStyleSheet(
            f"font-size: 18px; font-weight: bold; color: {self.colors['accent']};"
        )
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setWordWrap(True)
        layout.addWidget(title)

        desc = QLabel(f"Сайт <b>{origin}</b> запрашивает разрешение на использование устройства.")
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(desc)

        row = QHBoxLayout()
        deny_btn = QPushButton("Запретить")
        deny_btn.setStyleSheet(
            f"background-color: {self.colors['bg_input']};"
            f" color: {self.colors['text']};"
            f" border: 1px solid {self.colors['border']};"
        )
        deny_btn.clicked.connect(self.reject)

        allow_btn = QPushButton("Разрешить")
        allow_btn.clicked.connect(self.accept)

        row.addStretch()
        row.addWidget(deny_btn)
        row.addWidget(allow_btn)
        layout.addLayout(row)


class TabBarWithPlus(QTabBar):
    MIN_TAB_WIDTH = 40

    def __init__(self, parent=None):
        super().__init__(parent)
        self.colors = get_theme_colors()
        self.browser_window = None
        self.setExpanding(False)
        self.setMovable(True)
        self.setTabsClosable(True)
        self.setDocumentMode(True)
        self.setElideMode(Qt.TextElideMode.ElideRight)
        self.setIconSize(QSize(16, 16))
        self.setUsesScrollButtons(False)
        self.setStyleSheet(f"""
            QTabBar {{
                background: transparent;
            }}
            QTabBar::tab {{
                background: {self.colors['tab_bg']};
                border: none;
                border-radius: 6px;
                padding: 6px 8px 6px 12px;
                margin-right: 4px;
                margin-top: 4px;
                margin-bottom: 4px;
                color: {self.colors['text_muted']};
            }}
            QTabBar::tab:selected {{
                background: {self.colors['tab_selected_bg']};
                color: {self.colors['accent']};
                font-weight: bold;
                border: none;
            }}
            QTabBar::tab:hover:!selected {{
                background: {self.colors['hover']};
            }}
        """)

        self.plus_button = QToolButton(self)
        self.plus_button.setIcon(
            _make_icon("plus", self.colors["text_muted"], 16, self.colors["accent"])
        )
        self.plus_button.setIconSize(QSize(16, 16))
        self.plus_button.setToolTip("Новая вкладка")
        self.plus_button.setAutoRaise(True)
        self.plus_button.setFixedSize(28, 28)
        self.plus_button.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.plus_button.setStyleSheet(
            f"QToolButton {{ border-radius: 6px; padding: 0px; }}"
            f"QToolButton:hover {{ background-color: {self.colors['hover']}; }}"
        )
        self.plus_button.raise_()

    def connect_plus(self, callback):
        self.plus_button.clicked.connect(callback)

    def minimumSizeHint(self):
        return QSize(0, super().minimumSizeHint().height())

    def tabInserted(self, index):
        super().tabInserted(index)
        self._schedule()
        self._add_close_button(index)

    def _add_close_button(self, index):
        btn = QToolButton()
        btn.setIcon(_make_icon("close", self.colors["text_muted"], 12, "#FFFFFF"))
        btn.setIconSize(QSize(12, 12))
        btn.setFixedSize(18, 18)
        btn.setStyleSheet("""
            QToolButton { border: none; background: transparent;
                border-radius: 9px; padding: 0px; }
            QToolButton:hover { background: #FF5C5C; }
        """)
        btn.clicked.connect(lambda: self._on_tab_close_clicked(btn))
        self.setTabButton(index, QTabBar.ButtonPosition.RightSide, btn)

    def _on_tab_close_clicked(self, btn):
        for i in range(self.count()):
            if self.tabButton(i, QTabBar.ButtonPosition.RightSide) == btn:
                self.tabCloseRequested.emit(i)
                break

    def tabSizeHint(self, index):
        natural = super().tabSizeHint(index)
        btn = getattr(self, "plus_button", None)
        count = self.count()
        if btn is None or count == 0 or self.width() <= 0:
            return natural

        reserved = btn.width() + 8
        available = self.width() - reserved
        if available <= 0:
            return natural

        per_tab = available / count
        if natural.width() <= per_tab:
            return natural
        return QSize(max(self.MIN_TAB_WIDTH, int(per_tab)), natural.height())

    def _reposition(self, retry=5):
        if not hasattr(self, "plus_button"):
            return
        try:
            if self.count() == 0:
                x = 4
            else:
                rect = self.tabRect(self.count() - 1)
                if rect.width() <= 0:
                    if retry > 0:
                        QTimer.singleShot(10, lambda: self._reposition(retry - 1))
                    return
                x = rect.right() + 4
            y = max(2, (self.height() - self.plus_button.height()) // 2)
            self.plus_button.move(x, y)
            self.plus_button.raise_()
        except RuntimeError:
            pass

    def _schedule(self):
        if not hasattr(self, "plus_button"):
            return
        self._reposition()
        QTimer.singleShot(0, self._reposition)
        QTimer.singleShot(50, self._reposition)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._schedule()

    def showEvent(self, event):
        super().showEvent(event)
        self._schedule()

    def tabLayoutChange(self):
        super().tabLayoutChange()
        self._schedule()

    def tabRemoved(self, index):
        super().tabRemoved(index)
        self._schedule()

    def contextMenuEvent(self, event):
        index = self.tabAt(event.pos())
        if index < 0 or self.browser_window is None:
            return
        browser = self.browser_window.tabs.widget(index)
        if browser is None:
            return
        bw = self.browser_window
        menu = QMenu(self)
        menu.setStyleSheet(get_global_style(self.colors))

        new_tab_action = menu.addAction("Новая вкладка справа")
        reload_action = menu.addAction("Обновить вкладку")
        page = browser.page()
        muted = page is not None and page.isAudioMuted()
        mute_action = menu.addAction("Включить звук" if muted else "Отключить звук")
        pinned = browser in bw.pinned_tabs
        pin_action = menu.addAction("Открепить" if pinned else "Закрепить")
        discarded = id(browser) in bw.discarded_urls
        discard_action = menu.addAction("Восстановить" if discarded else "Выгрузить")
        duplicate_action = menu.addAction("Дублировать")
        menu.addSeparator()
        close_action = menu.addAction("Закрыть вкладку")
        action = menu.exec(event.globalPos())
        if action == new_tab_action:
            bw.add_new_tab_at(index + 1)
        elif action == reload_action:
            browser.reload()
        elif action == mute_action and page:
            page.setAudioMuted(not muted)
        elif action == pin_action:
            bw.toggle_pin_tab(index)
        elif action == discard_action:
            bw.restore_tab(index) if discarded else bw.discard_tab(index)
        elif action == duplicate_action:
            bw.add_new_tab(QUrl(browser.url()))
        elif action == close_action:
            bw.close_tab(index)


def _build_feature_names():
    pairs = [
        ("MediaAudioCapture", "микрофону"),
        ("MediaVideoCapture", "камере"),
        ("MediaAudioVideoCapture", "микрофону и камере"),
        ("Geolocation", "геолокации"),
        ("Notifications", "уведомлениям"),
        ("MouseLock", "блокировке курсора мыши"),
        ("ClipboardReadWrite", "буферу обмена"),
    ]
    out = {}
    for name, label in pairs:
        feat = getattr(QWebEnginePage.Feature, name, None)
        if feat is not None:
            out[feat] = label
    return out


def _build_blocked_features():
    result = set()
    for name in ("DesktopVideoCapture", "DesktopAudioVideoCapture"):
        feat = getattr(QWebEnginePage.Feature, name, None)
        if feat is not None:
            result.add(feat)
    return result


class WebPage(QWebEnginePage):
    _FEATURE_NAMES = _build_feature_names()
    _BLOCKED_FEATURES = _build_blocked_features()

    _TYPE_NAME_MAP = {
        "mediaaudiocapture":        "микрофону",
        "mediavideocapture":        "камере",
        "mediaaudiovideocapture":   "микрофону и камере",
        "geolocation":              "геолокации",
        "notifications":            "уведомлениям",
        "clipboardreadwrite":       "буферу обмена",
        "mouselock":                "блокировке курсора мыши",
    }

    _BLOCKED_TYPE_NAMES = ("desktopvideocapture", "desktopaudiovideocapture")

    def __init__(self, parent=None, browser_window=None, profile=None):
        if profile is not None:
            super().__init__(profile, parent)
        else:
            super().__init__(parent)
        self.browser_window = browser_window
        self._view_ref = parent

        self._has_new_api = False
        if hasattr(self, "permissionRequested"):
            try:
                self.permissionRequested.connect(self._on_permission_requested)
                self._has_new_api = True
            except (TypeError, RuntimeError):
                self._has_new_api = False

        if not self._has_new_api:
            try:
                self.featurePermissionRequested.connect(
                    self._on_feature_permission_requested
                )
            except (TypeError, RuntimeError):
                pass

    def _dialog_parent(self):
        if self._view_ref is not None:
            try:
                return self._view_ref.window()
            except (RuntimeError, AttributeError):
                return None
        if self.browser_window is not None:
            try:
                return self.browser_window
            except RuntimeError:
                return None
        return None

    def _on_permission_requested(self, permission):
        try:
            try:
                origin = permission.origin()
                display_origin = origin.host() or origin.toString() or "сайт"
            except Exception:
                display_origin = "сайт"

            feature_name = "устройствам"
            is_geo = False
            is_notifications = False
            is_blocked = False
            try:
                pt_val = permission.permissionType()
                pt_name = str(getattr(pt_val, "name", pt_val)).lower()
                if "." in pt_name:
                    pt_name = pt_name.rsplit(".", 1)[-1]
                feature_name = self._TYPE_NAME_MAP.get(pt_name, "устройствам")
                is_geo = pt_name == "geolocation"
                is_notifications = pt_name == "notifications"
                is_blocked = pt_name in self._BLOCKED_TYPE_NAMES
            except Exception:
                pass

            if is_blocked:
                permission.deny()
                return

            if is_notifications and not notifications_enabled():
                permission.deny()
                return

            dlg = PermissionDialog(display_origin, feature_name, self._dialog_parent())
            granted = dlg.exec() == QDialog.DialogCode.Accepted
            if granted:
                permission.grant()
                if is_geo and _GEO is not None:
                    _GEO.ensure()
            else:
                permission.deny()
        except Exception as e:
            print(f"Ошибка обработки permission: {e}")
            try:
                permission.deny()
            except Exception:
                pass

    def _on_feature_permission_requested(self, origin, feature):
        try:
            feature_name = self._FEATURE_NAMES.get(feature, "устройствам")
            display_origin = origin.host() or origin.toString()

            if feature in self._BLOCKED_FEATURES:
                self.setFeaturePermission(
                    origin, feature,
                    QWebEnginePage.PermissionPolicy.PermissionDeniedByUser,
                )
                return

            notif_feature = getattr(QWebEnginePage.Feature, "Notifications", None)
            if (
                notif_feature is not None
                and feature == notif_feature
                and not notifications_enabled()
            ):
                self.setFeaturePermission(
                    origin, feature,
                    QWebEnginePage.PermissionPolicy.PermissionDeniedByUser,
                )
                return

            dlg = PermissionDialog(display_origin, feature_name, self._dialog_parent())
            granted = dlg.exec() == QDialog.DialogCode.Accepted
            policy = (
                QWebEnginePage.PermissionPolicy.PermissionGrantedByUser
                if granted
                else QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
            )
            self.setFeaturePermission(origin, feature, policy)
            if (
                granted
                and feature == QWebEnginePage.Feature.Geolocation
                and _GEO is not None
            ):
                _GEO.ensure()
        except Exception as e:
            print(f"Ошибка обработки разрешения: {e}")
            try:
                self.setFeaturePermission(
                    origin, feature,
                    QWebEnginePage.PermissionPolicy.PermissionDeniedByUser,
                )
            except Exception:
                pass

    def createWindow(self, _type):
        if self.browser_window:
            return self.browser_window.add_new_tab_for_page().page()
        return super().createWindow(_type)


class BrowserWindow(QMainWindow):
    def __init__(self, private=False, restore_data=None):
        super().__init__()
        self.colors = get_theme_colors()
        self.private = private
        self.pinned_tabs = set()
        self.discarded_urls = {}
        self._fs_active = False
        self._fs_manual = False
        self._fs_browser = None
        self._fs_was_maximized = False
        self._was_maximized = False

        self.setWindowIcon(_app_icon())

        if private:
            self.profile = QWebEngineProfile(self)
            _set_ask_every_time(self.profile)
            if _GEO is not None:
                _GEO.register_profile(self.profile)
            if _NOTIFY is not None:
                _NOTIFY.register_profile(self.profile)
            if _DOWNLOADS is not None:
                _DOWNLOADS.register_profile(self.profile, private=True)
        else:
            self.profile = _get_persistent_profile()

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMinimumSize(640, 400)
        self.resize(1200, 800)

        self.base_widget = BaseWidget(self)
        self.setCentralWidget(self.base_widget)

        self.outer_layout = QVBoxLayout(self.base_widget)
        self.outer_layout.setContentsMargins(10, 10, 10, 10)

        self.main_container = QWidget()
        self.main_container.setObjectName("MainContainer")
        self.main_container.setStyleSheet(
            f"QWidget#MainContainer {{ background-color: {self.colors['bg']}; border-radius: 16px; }}"
        )
        self.outer_layout.addWidget(self.main_container)

        self.main_layout = QVBoxLayout(self.main_container)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        self.title_bar = CustomTitleBar(self)
        self.main_layout.addWidget(self.title_bar)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("QTabWidget::pane { border: none; }")
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.tab_bar = TabBarWithPlus()
        self.tab_bar.browser_window = self
        self.tabs.setTabBar(self.tab_bar)
        self.tab_bar.connect_plus(lambda: self.add_new_tab())
        self.main_layout.addWidget(self.tabs)

        self.find_bar = FindBar()
        self.main_layout.addWidget(self.find_bar)

        self.toolbar = QWidget()
        self.toolbar.setObjectName("Toolbar")
        self.toolbar.setStyleSheet(
            f"QWidget#Toolbar {{ background-color: {self.colors['bg']};"
            f" border-bottom: 1px solid {self.colors['border']}; }}"
        )
        toolbar_layout = QHBoxLayout(self.toolbar)
        toolbar_layout.setContentsMargins(10, 6, 10, 6)
        toolbar_layout.setSpacing(8)

        def nav_btn(kind, tip, slot):
            b = QToolButton()
            b.setIcon(_make_icon(kind, self.colors["text"], 18, self.colors["accent"]))
            b.setIconSize(QSize(18, 18))
            b.setToolTip(tip)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(slot)
            return b

        self.back_btn = nav_btn("back", "Назад", self.navigate_back)
        self.forward_btn = nav_btn("forward", "Вперёд", self.navigate_forward)
        self.reload_btn = nav_btn("reload", "Обновить", self.reload_page)
        self.home_btn = nav_btn("home", "Домашняя страница", self.go_home)
        self.bookmark_btn = nav_btn(
            "star", "Добавить в закладки (Ctrl+D)",
            lambda: self.toggle_bookmark(),
        )

        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Введите адрес или поисковый запрос...")
        self.url_bar.returnPressed.connect(self.navigate_to_url)

        toolbar_layout.addWidget(self.back_btn)
        toolbar_layout.addWidget(self.forward_btn)
        toolbar_layout.addWidget(self.reload_btn)
        toolbar_layout.addWidget(self.home_btn)
        toolbar_layout.addWidget(self.url_bar, 1)
        toolbar_layout.addWidget(self.bookmark_btn)

        self.main_layout.addWidget(self.toolbar)

        self.bookmarks_bar = BookmarksBar(self)
        self.main_layout.addWidget(self.bookmarks_bar)

        self._url_model = QStringListModel(self)
        self.url_completer = QCompleter(self)
        self.url_completer.setModel(self._url_model)
        self.url_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.url_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.url_completer.setCompletionMode(QCompleter.CompletionMode.UnfilteredPopupCompletion)
        self.url_completer.setMaxVisibleItems(15)
        self.url_bar.setCompleter(self.url_completer)
        self.url_bar.textEdited.connect(self._update_url_suggestions)
        self.url_completer.activated.connect(self._on_suggestion_activated)

        self.menu = QMenu(self)
        self._build_menu()

        self.find_bar.edit.textChanged.connect(self._on_find_text_changed)
        self.find_bar.edit.returnPressed.connect(self._find_next)
        self.find_bar.next_btn.clicked.connect(self._find_next)
        self.find_bar.prev_btn.clicked.connect(self._find_prev)
        self.find_bar.close_btn.clicked.connect(self.hide_find_bar)

        self._autosave_timer = QTimer(self)
        self._autosave_timer.timeout.connect(_save_current_sessions)
        self._autosave_timer.timeout.connect(self._save_window_geometry)
        self._autosave_timer.start(10000)

        self._restore_window_geometry()
        self._initial_restore(restore_data)
        self._update_bookmark_button()
        self._apply_bookmarks_bar_visibility()

    def _is_wayland(self):
        return QGuiApplication.platformName().startswith("wayland")

    def _restore_window_geometry(self):
        if self.private or not WINDOW_STATE_FILE.exists():
            return
        try:
            data = json.loads(WINDOW_STATE_FILE.read_text(encoding="utf-8"))
            screen = QApplication.primaryScreen().availableGeometry()
            w = max(640, min(int(data.get("w", 1200)), screen.width()))
            h = max(400, min(int(data.get("h", 800)), screen.height()))
            self.resize(w, h)
            if not self._is_wayland():
                x = max(screen.left(), min(int(data.get("x", 100)), screen.right() - 100))
                y = max(screen.top(), min(int(data.get("y", 100)), screen.bottom() - 100))
                self.move(x, y)
            if data.get("maximized"):
                QTimer.singleShot(0, self.showMaximized)
        except Exception:
            pass

    def _save_window_geometry(self):
        if self.private or not self.isVisible() or self.isFullScreen():
            return
        try:
            data = {}
            if WINDOW_STATE_FILE.exists():
                try:
                    data = json.loads(WINDOW_STATE_FILE.read_text(encoding="utf-8"))
                except Exception:
                    data = {}
            data["maximized"] = self.isMaximized()
            if not self.isMaximized() and not self.isFullScreen():
                data["w"] = self.width()
                data["h"] = self.height()
                if not self._is_wayland():
                    data["x"] = self.x()
                    data["y"] = self.y()
            SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
            WINDOW_STATE_FILE.write_text(json.dumps(data), encoding="utf-8")
        except Exception:
            pass

    def _get_resize_edge(self, pos):
        margin = 10
        edge = Qt.Edge(0)
        if pos.x() <= margin: edge |= Qt.Edge.LeftEdge
        if pos.x() >= self.width() - margin: edge |= Qt.Edge.RightEdge
        if pos.y() <= margin: edge |= Qt.Edge.TopEdge
        if pos.y() >= self.height() - margin: edge |= Qt.Edge.BottomEdge
        return edge

    def _handle_mouse_move(self, event):
        if self.isMaximized() or self.isFullScreen():
            self.unsetCursor()
            return
        edges = self._get_resize_edge(event.position().toPoint())
        if edges & Qt.Edge.LeftEdge and edges & Qt.Edge.TopEdge:
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        elif edges & Qt.Edge.RightEdge and edges & Qt.Edge.BottomEdge:
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        elif edges & Qt.Edge.RightEdge and edges & Qt.Edge.TopEdge:
            self.setCursor(Qt.CursorShape.SizeBDiagCursor)
        elif edges & Qt.Edge.LeftEdge and edges & Qt.Edge.BottomEdge:
            self.setCursor(Qt.CursorShape.SizeBDiagCursor)
        elif edges & Qt.Edge.LeftEdge or edges & Qt.Edge.RightEdge:
            self.setCursor(Qt.CursorShape.SizeHorCursor)
        elif edges & Qt.Edge.TopEdge or edges & Qt.Edge.BottomEdge:
            self.setCursor(Qt.CursorShape.SizeVerCursor)
        else:
            self.unsetCursor()

    def _handle_mouse_press(self, event):
        if (
            event.button() == Qt.MouseButton.LeftButton
            and not self.isMaximized()
            and not self.isFullScreen()
        ):
            edges = self._get_resize_edge(event.position().toPoint())
            if edges:
                self.windowHandle().startSystemResize(edges)
                return True
        return False

    def changeEvent(self, event):
        if event.type() == event.Type.WindowStateChange:
            if not self.isFullScreen() and not self.isMinimized():
                self._was_maximized = self.isMaximized()
            tb = getattr(self, "title_bar", None)
            if tb is not None:
                tb.update_max_icon(self.isMaximized())
            if hasattr(self, "outer_layout") and hasattr(self, "main_container"):
                if self.isMaximized() or self.isFullScreen():
                    self.outer_layout.setContentsMargins(0, 0, 0, 0)
                    self.main_container.setStyleSheet(
                        f"QWidget#MainContainer {{ background-color: {self.colors['bg']}; border-radius: 0px; }}"
                    )
                else:
                    self.outer_layout.setContentsMargins(10, 10, 10, 10)
                    self.main_container.setStyleSheet(
                        f"QWidget#MainContainer {{ background-color: {self.colors['bg']}; border-radius: 16px; }}"
                    )
        super().changeEvent(event)

    def _initial_restore(self, restore_data):
        urls = []
        active = 0
        if restore_data and not self.private:
            urls = list(restore_data.get("tabs") or [])
            active = restore_data.get("active", 0)

        if urls:
            for u in urls:
                self.add_new_tab(QUrl(u))
            if 0 <= active < self.tabs.count():
                self.tabs.setCurrentIndex(active)
        else:
            self.add_new_tab()

    def _update_title(self, title):
        self.title_bar.set_title(f"[Приватно] {title}" if self.private else title)

    def _build_menu(self):
        m = self.menu
        m.setStyleSheet(get_global_style(self.colors))

        new_tab_action = m.addAction("Новая вкладка")
        new_tab_action.setShortcut(QKeySequence("Ctrl+T"))
        new_tab_action.triggered.connect(lambda: self.add_new_tab())
        self.addAction(new_tab_action)

        new_window_action = m.addAction("Новое окно")
        new_window_action.setShortcut(QKeySequence("Ctrl+N"))
        new_window_action.triggered.connect(self.open_new_window)
        self.addAction(new_window_action)

        new_private_action = m.addAction("Новое приватное окно")
        new_private_action.setShortcut(QKeySequence("Ctrl+Shift+N"))
        new_private_action.triggered.connect(self.open_new_private_window)
        self.addAction(new_private_action)

        m.addSeparator()

        history_action = m.addAction("История")
        history_action.setShortcut(QKeySequence("Ctrl+H"))
        history_action.triggered.connect(self.show_history)
        self.addAction(history_action)

        bookmarks_menu = m.addMenu("Закладки")
        self.bookmarks_menu = bookmarks_menu
        self._bm_menu_actions = []

        add_bookmark_action = bookmarks_menu.addAction("Добавить закладку…")
        add_bookmark_action.setShortcut(QKeySequence("Ctrl+D"))
        add_bookmark_action.triggered.connect(self.show_add_bookmark)
        self.addAction(add_bookmark_action)

        bookmarks_manager_action = bookmarks_menu.addAction("Менеджер закладок")
        bookmarks_manager_action.setShortcut(QKeySequence("Ctrl+Shift+O"))
        bookmarks_manager_action.triggered.connect(self.show_bookmarks)
        self.addAction(bookmarks_manager_action)

        bookmarks_bar_action = bookmarks_menu.addAction("Панель закладок")
        bookmarks_bar_action.setCheckable(True)
        bookmarks_bar_action.setChecked(self._bookmarks_bar_enabled())
        bookmarks_bar_action.setShortcut(QKeySequence("Ctrl+Shift+B"))
        bookmarks_bar_action.toggled.connect(self.set_bookmarks_bar_visible)
        self.addAction(bookmarks_bar_action)
        self.bookmarks_bar_action = bookmarks_bar_action

        bookmarks_menu.addSeparator()
        bookmarks_menu.aboutToShow.connect(self._populate_bookmarks_menu)

        downloads_action = m.addAction("Загрузки")
        downloads_action.setShortcut(QKeySequence("Ctrl+J"))
        downloads_action.triggered.connect(self.show_downloads)
        self.addAction(downloads_action)

        settings_action = m.addAction("Настройки")
        settings_action.setShortcut(QKeySequence("Ctrl+,"))
        settings_action.triggered.connect(self.open_settings)
        self.addAction(settings_action)

        clear_data_action = m.addAction("Очистить данные…")
        clear_data_action.setShortcut(QKeySequence("Ctrl+Shift+Del"))
        clear_data_action.triggered.connect(self.show_clear_data)
        self.addAction(clear_data_action)

        m.addSeparator()

        find_action = m.addAction("Найти на странице")
        find_action.setShortcut(QKeySequence("Ctrl+F"))
        find_action.triggered.connect(self.show_find_bar)
        self.addAction(find_action)

        m.addSeparator()

        fullscreen_action = m.addAction("Полный экран")
        fullscreen_action.setShortcut(QKeySequence("F11"))
        fullscreen_action.triggered.connect(self.toggle_fullscreen)
        self.addAction(fullscreen_action)

        self.esc_action = QAction(self)
        self.esc_action.setShortcut(QKeySequence("Esc"))
        self.esc_action.setEnabled(False)
        self.esc_action.triggered.connect(self._exit_fullscreen)
        self.addAction(self.esc_action)

        zoom_menu = m.addMenu("Масштаб")
        zoom_in = zoom_menu.addAction("Увеличить")
        zoom_in.triggered.connect(self.zoom_in)
        zoom_out = zoom_menu.addAction("Уменьшить")
        zoom_out.triggered.connect(self.zoom_out)
        zoom_reset = zoom_menu.addAction("Сбросить (100%)")
        zoom_reset.triggered.connect(self.zoom_reset)

        m.addSeparator()

        help_menu = m.addMenu("Справка")
        about_action = help_menu.addAction("О FurryBrowser")
        about_action.triggered.connect(self.show_about)

    def _show_menu(self):
        pos = self.title_bar.menu_button.mapToGlobal(self.title_bar.menu_button.rect().bottomLeft())
        self.menu.exec(pos)

    def show_about(self):
        dlg = QDialog(self)
        dlg.setStyleSheet(get_global_style(self.colors))
        dlg.setWindowTitle("О FurryBrowser")
        dlg.setWindowIcon(_app_icon())
        dlg.setMinimumWidth(400)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        art_path = ASSETS_DIR / "about_art.png"
        img_label = QLabel()
        if art_path.exists():
            pixmap = QPixmap(str(art_path)).scaled(
                250, 250,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            img_label.setPixmap(pixmap)
        else:
            img_label.setPixmap(_icon_pixmap("paw", self.colors["accent"], 120))
        img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(img_label)

        title = QLabel("FurryBrowser")
        title.setStyleSheet(f"font-size: 22px; font-weight: bold; color: {self.colors['accent']};")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        version = QLabel("Версия 1.0 PAW (Persistent Amendment Wave)")
        version.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(version)

        layout.addSpacing(10)

        desc = QLabel("Ваша приватность в надёжных лапах.\n\n")
        desc.setWordWrap(True)
        layout.addWidget(desc)
        layout.addSpacing(10)

        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(dlg.accept)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(close_btn)
        row.addStretch()
        layout.addLayout(row)

        dlg.exec()

    def open_new_window(self):
        w = BrowserWindow(private=False)
        _WINDOWS.append(w)
        w.show()

    def open_new_private_window(self):
        w = BrowserWindow(private=True)
        _WINDOWS.append(w)
        w.show()

    def open_settings(self):
        dlg = SettingsDialog(self)
        dlg.setStyleSheet(get_global_style(self.colors))
        dlg.exec()

    def show_clear_data(self):
        ClearDataDialog(self).exec()

    def _add_tab_at(self, index, url=None):
        browser = CustomWebEngineView(self)
        browser.page().setBackgroundColor(QColor(self.colors["bg"]))
        page = WebPage(browser, self, self.profile)
        browser.setPage(page)
        page.settings().setAttribute(
            QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True
        )
        page.fullScreenRequested.connect(
            lambda req, b=browser: self._on_fullscreen_requested(req, b)
        )
        page.findTextFinished.connect(self._on_find_finished)

        self.tabs.insertTab(index, browser, "Новая вкладка")
        self.tabs.setCurrentIndex(index)

        browser.urlChanged.connect(lambda qurl, b=browser: self.update_url_bar(qurl, b))
        browser.titleChanged.connect(lambda title, b=browser: self.update_tab_title(title, b))
        browser.loadFinished.connect(lambda ok, b=browser: self._on_load_finished(ok, b))
        browser.urlChanged.connect(lambda _qurl: QTimer.singleShot(500, _save_current_sessions))
        browser.iconChanged.connect(lambda _i, b=browser: self._refresh_tab_icon(b))
        self._refresh_tab_icon(browser)

        if url is not None:
            browser.setUrl(url)
        return browser

    def _refresh_tab_icon(self, browser):
        index = self.tabs.indexOf(browser)
        if index == -1:
            return
        c = self.colors
        if id(browser) in self.discarded_urls:
            icon = _make_icon("sleep", c["text_muted"], 16)
        elif browser in self.pinned_tabs:
            icon = _make_icon("pin", c["accent"], 16)
        else:
            icon = browser.icon()
            if icon.isNull():
                icon = _make_icon("globe", c["text_muted"], 16)
        self.tabs.setTabIcon(index, icon)

    def _on_fullscreen_requested(self, request, browser):
        request.accept()
        if request.toggleOn():
            self._enter_fullscreen(browser)
        else:
            if browser is self._fs_browser:
                self._fs_browser = None
            if not self._fs_manual:
                self._leave_fullscreen_ui()

    def _enter_fullscreen(self, browser=None, manual=False):
        if self._fs_active:
            if browser is not None:
                self._fs_browser = browser
            return
        self._fs_active = True
        self._fs_manual = manual
        self._fs_browser = browser

        screen = self.screen()
        avail = screen.availableGeometry() if screen else None
        visually_max = (
            avail is not None
            and self.width() >= avail.width()
            and self.height() >= avail.height()
        )
        self._fs_was_maximized = (
            self._was_maximized or self.isMaximized() or visually_max
        )

        self.title_bar.hide()
        self.tab_bar.hide()
        self.toolbar.hide()
        self.bookmarks_bar.hide()
        self.find_bar.hide()
        self.esc_action.setEnabled(True)
        self.showFullScreen()

    def _leave_fullscreen_ui(self):
        if not self._fs_active:
            return
        self._fs_active = False
        self._fs_manual = False
        self._fs_browser = None
        self.esc_action.setEnabled(False)
        self.title_bar.show()
        self.tab_bar.show()
        self.toolbar.show()
        self._apply_bookmarks_bar_visibility()
        if self._fs_was_maximized:
            self.showMaximized()
            QTimer.singleShot(0, self._ensure_maximized)
            QTimer.singleShot(150, self._ensure_maximized)
        else:
            self.showNormal()

    def _ensure_maximized(self):
        if self._fs_active or self.isFullScreen():
            return
        if not self.isMaximized():
            self.showMaximized()

    def _exit_fullscreen(self):
        b = self._fs_browser
        if b is not None:
            self._fs_browser = None
            try:
                b.page().triggerAction(QWebEnginePage.WebAction.ExitFullScreen)
            except (RuntimeError, AttributeError):
                pass
            if self._fs_manual:
                return
        self._leave_fullscreen_ui()

    def toggle_fullscreen(self):
        if self._fs_active:
            self._fs_manual = False
            self._exit_fullscreen()
        else:
            self._enter_fullscreen(manual=True)

    def add_new_tab_for_page(self):
        return self._add_tab_at(self.tabs.count())

    def add_new_tab(self, url=None):
        browser = self.add_new_tab_for_page()
        browser.setUrl(url if url is not None else get_home_url())
        self.url_bar.setFocus()
        QTimer.singleShot(300, _save_current_sessions)
        return browser

    def add_new_tab_at(self, index, url=None):
        b = self._add_tab_at(index, url if url is not None else get_home_url())
        QTimer.singleShot(300, _save_current_sessions)
        return b

    def toggle_pin_tab(self, index):
        browser = self.tabs.widget(index)
        if not browser:
            return
        pinned_count = sum(
            1 for i in range(self.tabs.count())
            if self.tabs.widget(i) in self.pinned_tabs
        )
        if browser in self.pinned_tabs:
            self.pinned_tabs.discard(browser)
            self.tab_bar.moveTab(index, pinned_count - 1)
        else:
            self.pinned_tabs.add(browser)
            self.tab_bar.moveTab(index, pinned_count)
        self.update_tab_title(browser.title(), browser)
        self._refresh_tab_icon(browser)

    def discard_tab(self, index):
        browser = self.tabs.widget(index)
        if not browser or id(browser) in self.discarded_urls:
            return
        url = browser.url()
        if url.isEmpty() or url.toString() in ("about:blank", ""):
            return
        self.discarded_urls[id(browser)] = url
        browser.setUrl(QUrl("about:blank"))
        self.tabs.setTabText(index, "Выгружено")
        self._refresh_tab_icon(browser)

    def restore_tab(self, index):
        browser = self.tabs.widget(index)
        if not browser or id(browser) not in self.discarded_urls:
            return
        browser.setUrl(self.discarded_urls.pop(id(browser)))
        self._refresh_tab_icon(browser)

    def close_tab(self, index):
        browser = self.tabs.widget(index)
        if browser:
            if browser is self._fs_browser:
                self._exit_fullscreen()
            self.pinned_tabs.discard(browser)
            self.discarded_urls.pop(id(browser), None)
        if self.tabs.count() > 1:
            self.tabs.removeTab(index)
            if browser:
                browser.deleteLater()
        else:
            if browser:
                browser.setUrl(get_home_url())
                self.tabs.setTabText(0, "Новая вкладка")
                self._refresh_tab_icon(browser)
        QTimer.singleShot(100, _save_current_sessions)

    def current_tab_changed(self, index):
        if index < 0:
            return
        browser = self.tabs.widget(index)
        if not browser:
            return
        if self._fs_browser is not None and self._fs_browser is not browser:
            self._exit_fullscreen()
        if id(browser) in self.discarded_urls:
            url = self.discarded_urls.pop(id(browser))
            browser.setUrl(url)
            self._refresh_tab_icon(browser)
            self.url_bar.setText(url.toString())
            self._update_title("Загрузка…")
        else:
            self.url_bar.setText(browser.url().toString())
            self._update_title(browser.title() or "Новая вкладка")

        if self.find_bar.isVisible() and self.find_bar.edit.text():
            self._find_next()

        self._update_bookmark_button()
        QTimer.singleShot(200, _save_current_sessions)

    def current_browser(self):
        return self.tabs.currentWidget()

    def update_url_bar(self, qurl, browser):
        if id(browser) in self.discarded_urls:
            if qurl.toString() in ("about:blank", ""):
                return
            self.discarded_urls.pop(id(browser), None)
            self._refresh_tab_icon(browser)
        if browser is self.tabs.currentWidget():
            self.url_bar.setText(qurl.toString())
            self.url_bar.setCursorPosition(0)
            self._update_bookmark_button()

        host = qurl.host()
        if host and browser.page():
            zoom = _ZOOM_LEVELS.get(host, 1.0)
            if abs(browser.page().zoomFactor() - zoom) > 0.01:
                browser.page().setZoomFactor(zoom)

    def update_tab_title(self, title, browser):
        if not title:
            title = "Новая вкладка"
        index = self.tabs.indexOf(browser)
        if index == -1:
            return
        discarded = id(browser) in self.discarded_urls
        self.tabs.setTabText(index, "Выгружено" if discarded else title[:30])
        self._refresh_tab_icon(browser)
        if browser is self.tabs.currentWidget() and not discarded:
            self._update_title(title)

    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        if text in ("furrybrowser://settings", "about:settings"):
            self.open_settings()
            return
        browser = self.current_browser()
        looks_like_url = (
            " " not in text
            and (
                text.startswith(("http://", "https://", "ftp://", "file://"))
                or text == "localhost"
                or text.startswith("localhost:")
                or ("." in text and not text.endswith("."))
            )
        )
        if looks_like_url:
            url = QUrl(text)
            if not url.scheme():
                url.setScheme("https")
        else:
            url = get_search_url(text)
        if browser:
            browser.setUrl(url)

    def navigate_back(self):
        b = self.current_browser()
        if b:
            b.back()

    def navigate_forward(self):
        b = self.current_browser()
        if b:
            b.forward()

    def reload_page(self):
        b = self.current_browser()
        if b:
            b.reload()

    def go_home(self):
        b = self.current_browser()
        if b:
            b.setUrl(get_home_url())
            self.url_bar.clear()

    def _on_load_finished(self, ok, browser):
        try:
            host = browser.url().host()
            if host and browser.page():
                zoom = _ZOOM_LEVELS.get(host, 1.0)
                if abs(browser.page().zoomFactor() - zoom) > 0.01:
                    browser.page().setZoomFactor(zoom)
        except Exception:
            pass

        self._update_bookmark_button()

        if not ok or self.private:
            return
        url_str = browser.url().toString()
        if not url_str or url_str == "about:blank" or url_str.startswith("furrybrowser:"):
            return
        title = browser.title() or url_str
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        _HISTORY.append((url_str, title, ts))
        if len(_HISTORY) > 2000:
            del _HISTORY[:500]
        _save_history()
        QTimer.singleShot(500, _save_current_sessions)

    def show_downloads(self):
        if _DOWNLOADS is not None:
            _DOWNLOADS.show_dialog()

    def show_history(self):
        dlg = HistoryDialog(self)
        dlg.open_callback = self.add_new_tab
        dlg.exec()

    def _bookmarks_bar_enabled(self):
        try:
            return bool(load_settings().get("bookmarks_bar", True))
        except Exception:
            return True

    def _apply_bookmarks_bar_visibility(self):
        bar = getattr(self, "bookmarks_bar", None)
        if bar is None:
            return
        visible = (
            self._bookmarks_bar_enabled()
            and bool(_BOOKMARKS)
            and not self._fs_active
        )
        bar.setVisible(visible)

    def set_bookmarks_bar_visible(self, visible):
        settings = load_settings()
        settings["bookmarks_bar"] = bool(visible)
        save_settings(settings)
        _refresh_bookmark_ui()

    def _update_bookmark_button(self):
        btn = getattr(self, "bookmark_btn", None)
        if btn is None:
            return
        browser = self.current_browser() if hasattr(self, "tabs") else None
        try:
            url = browser.url().toString() if browser is not None else ""
        except (RuntimeError, AttributeError):
            url = ""
        marked = bool(url) and _find_bookmark(url) is not None
        color = self.colors["accent"] if marked else self.colors["text"]
        btn.setIcon(
            _make_icon(
                "star_filled" if marked else "star",
                color, 18, self.colors["accent"],
            )
        )
        btn.setToolTip(
            "Убрать из закладок" if marked
            else "Добавить в закладки (Ctrl+D)"
        )

    def toggle_bookmark(self, browser=None):
        browser = browser or self.current_browser()
        if browser is None:
            return
        try:
            url = browser.url().toString()
            title = browser.title() or url
        except (RuntimeError, AttributeError):
            return
        if not url or url == "about:blank" or url.startswith("furrybrowser:"):
            return
        if _find_bookmark(url) is not None:
            remove_bookmark(url)
        else:
            add_bookmark(url, title)
        _refresh_bookmark_ui()

    def show_add_bookmark(self):
        browser = self.current_browser()
        url = ""
        title = ""
        if browser is not None:
            try:
                url = browser.url().toString()
                title = browser.title() or ""
            except (RuntimeError, AttributeError):
                url, title = "", ""
        if url in ("about:blank",) or url.startswith("furrybrowser:"):
            url, title = "", ""
        existing = _find_bookmark(url) if url else None
        dlg = BookmarkEditDialog(
            self, bookmark=existing, title=title, url=url,
        )
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.refresh_bookmarks()

    def edit_bookmark(self, url):
        bookmark = _find_bookmark(url)
        if bookmark is None:
            return
        dlg = BookmarkEditDialog(self, bookmark=bookmark)
        dlg.exec()
        self.refresh_bookmarks()

    def open_bookmark(self, url):
        qurl = url if isinstance(url, QUrl) else QUrl(str(url))
        browser = self.current_browser()
        if browser is None:
            self.add_new_tab(qurl)
        else:
            browser.setUrl(qurl)

    def show_bookmarks(self):
        dlg = BookmarksDialog(self)
        dlg.open_callback = self.open_bookmark
        dlg.open_new_tab_callback = self.add_new_tab
        dlg.exec()
        self.refresh_bookmarks()

    def _populate_bookmarks_menu(self):
        menu = getattr(self, "bookmarks_menu", None)
        if menu is None:
            return
        for action in getattr(self, "_bm_menu_actions", []):
            menu.removeAction(action)
            action.deleteLater()
        self._bm_menu_actions = []

        if not _BOOKMARKS:
            action = menu.addAction("Закладок пока нет")
            action.setEnabled(False)
            self._bm_menu_actions.append(action)
            return

        for bookmark in _BOOKMARKS[:20]:
            title = bookmark.get("title") or bookmark.get("url") or ""
            if len(title) > 48:
                title = title[:47] + "…"
            action = menu.addAction(title)
            action.setToolTip(bookmark.get("url", ""))
            url = bookmark.get("url")
            action.triggered.connect(
                lambda checked=False, u=url: self.add_new_tab(QUrl(u))
            )
            self._bm_menu_actions.append(action)

        if len(_BOOKMARKS) > 20:
            action = menu.addAction(f"Ещё закладки ({len(_BOOKMARKS) - 20})…")
            action.triggered.connect(self.show_bookmarks)
            self._bm_menu_actions.append(action)

    def refresh_bookmarks(self):
        self._update_bookmark_button()
        bar = getattr(self, "bookmarks_bar", None)
        if bar is not None:
            bar.rebuild()
        action = getattr(self, "bookmarks_bar_action", None)
        if action is not None:
            wanted = self._bookmarks_bar_enabled()
            if action.isChecked() != wanted:
                action.blockSignals(True)
                action.setChecked(wanted)
                action.blockSignals(False)
        self._apply_bookmarks_bar_visibility()

    def show_find_bar(self):
        browser = self.current_browser()
        if not browser:
            return
        self.find_bar.setVisible(True)
        self.find_bar.edit.setFocus()
        self.find_bar.edit.selectAll()
        if self.find_bar.edit.text():
            self._find_next()

    def hide_find_bar(self):
        self.find_bar.setVisible(False)
        b = self.current_browser()
        if b and b.page():
            b.page().findText("")

    def _on_find_text_changed(self, text):
        if not self.find_bar.isVisible():
            return
        b = self.current_browser()
        if b and b.page():
            b.page().findText(text)

    def _find_next(self):
        b = self.current_browser()
        if b and b.page():
            b.page().findText(self.find_bar.edit.text())

    def _find_prev(self):
        b = self.current_browser()
        if b and b.page():
            text = self.find_bar.edit.text()
            if text:
                b.page().findText(text, QWebEnginePage.FindFlag.FindBackward)

    def _on_find_finished(self, result):
        if self.find_bar.isVisible():
            self.find_bar.set_status(result.numberOfMatches(), result.activeMatch())

    def _update_url_suggestions(self, text):
        if not text:
            self._url_model.setStringList([])
            self.url_completer.popup().hide()
            return
        try:
            settings = load_settings()
            addr = settings.get("address_bar", {})
            text_lower = text.lower()
            items = []
            seen = set()

            if addr.get("bookmarks", True):
                for bookmark in reversed(_BOOKMARKS):
                    url = bookmark.get("url") or ""
                    title = bookmark.get("title") or ""
                    if not url or url in seen:
                        continue
                    if text_lower in url.lower() or text_lower in title.lower():
                        seen.add(url)
                        items.append(url)

            if addr.get("history", True):
                for url, title, _ in _HISTORY[-300:]:
                    if not url or url in seen:
                        continue
                    if text_lower in url.lower() or text_lower in (title or "").lower():
                        seen.add(url)
                        items.append(url)

            if addr.get("open_tabs", True):
                for i in range(self.tabs.count()):
                    try:
                        b = self.tabs.widget(i)
                        if b is None:
                            continue
                        u = b.url().toString()
                    except (RuntimeError, AttributeError):
                        continue
                    if not u or u in ("about:blank", "") or u in seen:
                        continue
                    if text_lower in u.lower():
                        seen.add(u)
                        items.append(u)

            items = items[:15]
            self._url_model.setStringList(items)
            self.url_completer.setCompletionPrefix(text)
            if items:
                self.url_completer.complete()
            else:
                self.url_completer.popup().hide()
        except Exception:
            self._url_model.setStringList([])

    def _on_suggestion_activated(self, text):
        self.url_bar.setText(text)
        self.navigate_to_url()

    def _apply_zoom(self, delta, absolute=None):
        b = self.current_browser()
        if not b or not b.page():
            return
        if absolute is not None:
            new_zoom = absolute
        else:
            new_zoom = b.page().zoomFactor() + delta
        new_zoom = max(0.25, min(new_zoom, 5.0))
        b.page().setZoomFactor(new_zoom)
        host = b.url().host()
        if host:
            _ZOOM_LEVELS[host] = new_zoom
            _save_zoom_levels()

    def zoom_in(self):
        self._apply_zoom(0.1)

    def zoom_out(self):
        self._apply_zoom(-0.1)

    def zoom_reset(self):
        self._apply_zoom(0, absolute=1.0)

    def closeEvent(self, event):
        if not self.private:
            self._save_window_geometry()
        else:
            if _GEO is not None:
                _GEO.unregister_profile(self.profile)
            if _NOTIFY is not None:
                _NOTIFY.unregister_profile(self.profile)
        if self in _WINDOWS:
            _WINDOWS.remove(self)
        _save_current_sessions()
        super().closeEvent(event)


def main():
    global _HISTORY, _BOOKMARKS, _GEO, _NOTIFY, _DOWNLOADS
    _HISTORY = _load_history()
    _BOOKMARKS = _load_bookmarks()
    _load_zoom_levels()

    sys.excepthook = lambda tp, val, tb: traceback.print_exception(tp, val, tb)

    signal.signal(signal.SIGINT, signal.SIG_DFL)

    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)

    flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
    if "--lang=ru" not in flags:
        flags += " --lang=ru"
    if "--enable-gpu-rasterization" not in flags:
        flags += " --enable-gpu-rasterization"
    if "--enable-zero-copy" not in flags:
        flags += " --enable-zero-copy"
    if "--ignore-gpu-blocklist" not in flags:
        flags += " --ignore-gpu-blocklist"
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        if "--no-sandbox" not in flags:
            flags += " --no-sandbox"
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = flags.strip()

    if sys.platform.startswith("linux"):
        os.environ.setdefault("QT_MEDIA_BACKEND", "gstreamer")

    app = QApplication(sys.argv)
    app.setOrganizationName("FurryBrowser")
    app.setApplicationName("FurryBrowser")
    app.setApplicationVersion("1.0")
    app.setWindowIcon(_app_icon())

    colors = get_theme_colors()
    app.setStyleSheet(get_global_style(colors))

    _GEO = GeoLocator(app)
    _NOTIFY = NotificationManager(app)
    _DOWNLOADS = DownloadManager(DOWNLOADS_FILE, get_theme_colors, get_global_style, app)

    def _graceful_shutdown():
        if _DOWNLOADS is not None:
            _DOWNLOADS.shutdown()
        if _NOTIFY is not None:
            _NOTIFY.close_all()
        for w in list(_WINDOWS):
            try:
                for i in range(w.tabs.count()):
                    b = w.tabs.widget(i)
                    if b and b.page():
                        b.setUrl(QUrl("about:blank"))
            except (RuntimeError, AttributeError):
                pass
        QApplication.processEvents()
        _save_history()
        _save_bookmarks()
        _save_current_sessions()
        _save_zoom_levels()

    app.aboutToQuit.connect(_graceful_shutdown)

    splash = SplashScreen()
    splash.center_on_screen()
    splash.show()
    app.processEvents()

    def start_browser():
        restored = False
        if load_settings().get("open_previous_tabs") and SESSION_FILE.exists():
            try:
                data = json.loads(SESSION_FILE.read_text(encoding="utf-8"))
            except Exception:
                data = None
            if data:
                windows = data.get("windows") if isinstance(data, dict) else (
                    [{"tabs": data, "active": 0}] if data else []
                )
                if windows:
                    for wd in windows:
                        if not isinstance(wd, dict) or not (wd.get("tabs") or []):
                            continue
                        w = BrowserWindow(restore_data=wd)
                        _WINDOWS.append(w)
                        w.show()
                        restored = True

        if not restored:
            w = BrowserWindow()
            _WINDOWS.append(w)
            w.show()

        splash.close()
        QTimer.singleShot(500, _save_current_sessions)

    QTimer.singleShot(2500, start_browser)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()